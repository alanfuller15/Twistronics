# v074p — response to the v073p variant-controls review (branch `variant-controls-review`)

Partner, 22 September 2026. One core, single-thread BLAS, Python 3.12.3 / NumPy 2.4.4 / SciPy 1.17.1. All seven findings accepted; none disputed. Exploratory controls, not gated acceptance. The sparse F01–F08 blockers are untouched by this package and remain open.

## Finding responses

| ID | Finding | Correction | Evidence |
|---|---|---|---|
| **V01** | Fast engine ignores `valley`; every K′ sample off by 43–100 meV. **My v073p claim that "every downstream tool applies unchanged" was false.** | `RealEngine` now transforms the static part (conjugation) and evaluates the kinetic blocks at −k with the σ_x coefficient sign following the valley; `CertifiedSparse.S_k` carries the same rule. Verified against the native Hamiltonian at 9 points × 3 cutoffs × both valleys: max matrix error 4.6×10⁻¹³ meV, max energy error 4.7×10⁻¹³ meV; sparse K′ window 3.0×10⁻¹³ meV. | `fast_engine.py`, `sparse_mode_v2.py`; test `test_V01_fast_and_sparse_engines_follow_the_valley` (both valleys, three momenta, dense + sparse) |
| **V02** | The fully mirrored label had no supplied producer, and four JSON fields were dropped. | `producers.py` generates all three measurements explicitly — K, K′ with unmirrored start, K′ fully mirrored — with `start_offset` and periodic `image` as arguments recorded in the output. Records are written whole, not patched. Result: B=−0.30 gives K OPPOSITE, K′ unmirrored SAME, K′ fully mirrored **OPPOSITE**; B=−0.25 gives SAME in all three. | `producers.py`, `VALLEY_MIRROR.json` (`braid_-0.3.Kprime_fully_mirrored`) |
| **V03** | `min_det` was the minimum polar-factor determinant of whole loop products, not a plaquette determinant or an isolation bound. | Renamed `min_polar_det` and reported beside the quantities it was mistaken for: `min_overlap_singular_value`, `max_sewing_loss`, `max_reality_residual`, `min_external_gap_meV`. My v073p sentence "all plaquette dets +1" is **withdrawn**. | `topo.euler_wilson`; test `test_V03_diagnostics_are_named_for_what_they_are` |
| **V04** | Sign helper discarded the imaginary part without enforcing reality (mass model returned ≈0.999998). | All frames go through `frame_at`, which refuses a model with real-basis residual ≥ 10⁻⁹ meV; band degeneracy along the cycle is refused separately and the minimum band gap is recorded. | `topo.py`; test `test_V04_non_real_model_is_refused_by_the_frame_path` |
| **V05** | `euler_wilson(lo=…)` ignored `lo`. | `lo` selects the pair and is range-checked; out-of-range raises. | test `test_V05_band_selection_is_honoured_and_out_of_range_is_refused` |
| **V06** | "sum +2 = 2e₂" contradicted the retained e₂ = −1; APY write the total winding as −2e₂. | The signed claim is **withdrawn**. The record now states magnitude agreement only (\|sum\| = 2\|e₂\|) and notes the convention split (arXiv −2e₂, PRX +2e₂) together with this estimator's arbitrary base-frame orientation. | `CHIRAL_CONTROL.json` → `nodes.signed_statement` |
| **V07** | The bandwidth scan was inherited from an older JSON, not recomputed. | `producers.py` recomputes everything it reports: 16-row α scan (θ = 1.03–1.10°, step 0.01°, N = 6 and 8, 10×10 fractional grid per point), the chiral symmetry residual, the Euler diagnostics and the node measurement. The minimum is labelled a **sampled** minimum with its two neighbouring samples recorded. | `CHIRAL_CONTROL.json` → `bandwidth_scan`, `sampled_minimum_N6/N8` |

## Recomputed results

Chiral limit (w₀ = 0, unstrained): sampled minimum bandwidth **0.8544 meV at θ = 1.06°, α = 0.5875**, identical at N = 6 and N = 8, neighbours α = 0.5931 and 0.5820. Reference: Tarnopolsky–Kruchkov–Vishwanath report a first magic coupling ≈ 0.586; as the review notes, that decimal is not an exact analytic constant, and a minimum on a 0.01° grid is a sampled minimum, not a certified bracket. Chiral symmetry residual 1.2×10⁻¹¹ meV. Wilson estimate \|e₂\| = 1.000 with closure 0.993, min overlap singular value 0.73, max sewing loss 0.014, min external gap 5.3 meV. Nodes found near (0,0) and (1/3,1/3) on a 12×12 grid — a discovery, not an inventory.

Valley: baseline \|e₂\| = 1.000 in both valleys, closures +0.997 and +0.996; endpoint per-band signs identical in both valleys (flat₁ k₁ −1, k₂ +1; flat₂ +1, +1) with the minimum band gap recorded per cycle. Signs of Euler estimates remain convention-dependent and are not compared.

## Scope
The native K′ definition is an algebraic wrapper on the K model, as the review says — not a second independently coded valley. Nothing here closes a sparse integration blocker, establishes a complete inventory, a continuous path, a braid, an Euler-class change, physical validation or novelty.

## Reproduce
```
python producers.py          # recomputes both controls and writes CHIRAL_CONTROL.json, VALLEY_MIRROR.json
python -m pytest test_valley_chiral.py -q
```
