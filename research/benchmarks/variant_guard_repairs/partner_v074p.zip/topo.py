"""topo.py — topology measurements with the guards the v073p review required (partner v074p).

V03: the Wilson diagnostic formerly called `min_det` is the minimum determinant of the polar factor of a whole
     k2 loop product; it is renamed `min_polar_det` and reported alongside the quantities it was mistaken for:
     the minimum overlap singular value along the loop, the sewing norm loss, and the reality residual.
V04: every frame is built through a reality-enforcing path; a non-real model (e.g. a C2zT-breaking mass) is refused
     rather than silently projected, and band degeneracy along a sign-holonomy path is rejected.
V05: `lo` selects the band pair; it is no longer ignored.
Valley-aware periodic sewing (v073p) is retained."""
import numpy as np
from scipy.linalg import eigh
from gate import real_basis, classify
from euler import shift_matrix
from braid import node_winding, transport
REAL_TOL = 1e-9
class RealityError(RuntimeError): pass
class DegeneracyError(RuntimeError): pass
def frame_at(m, U, k, lo, n=2):
    """real-basis frame of ABSOLUTE bands lo..lo+n-1, with the reality precondition enforced (V04, V05)"""
    HR = U.conj().T @ m.H(k) @ U; res = float(np.abs(HR.imag).max())
    if not res < REAL_TOL: raise RealityError(f'model is not real in the C2zT basis: max|Im| = {res:.2e} meV')
    w, v = eigh(HR.real, subset_by_index=(lo, lo + n - 1)); return w, v
def euler_wilson(m, U, lo=None, nf1=24, nf2=40, gap_tol=0.0):
    """Wilson-loop Euler estimate for the pair (lo, lo+1). Returns a dict of diagnostics, each named for what it is."""
    D = m.dim; lo = D // 2 - 1 if lo is None else int(lo); v = int(getattr(m, 'valley', 1))
    if lo < 0 or lo + 1 >= D: raise ValueError(f'band pair (lo, lo+1) = ({lo}, {lo+1}) outside 0..{D-1}')
    S2 = shift_matrix(m, (0, -v)); S1 = shift_matrix(m, (-v, 0))
    bp = b0 = None; ph = []; polar = []; svmin = 1.0; sew = 0.0; realres = 0.0; extmin = np.inf
    for f1 in np.linspace(0, 1, nf1, endpoint=False):
        fr = []
        for f2 in np.linspace(0, 1, nf2, endpoint=False):
            k = m.frac_to_k(np.array([f1, f2])); HR = U.conj().T @ m.H(k) @ U
            realres = max(realres, float(np.abs(HR.imag).max()))
            if not realres < REAL_TOL: raise RealityError(f'model is not real in the C2zT basis: max|Im| = {realres:.2e} meV')
            w4, vv = eigh(HR.real, subset_by_index=(max(lo - 1, 0), min(lo + 2, D - 1)))
            j = lo - max(lo - 1, 0)
            if len(w4) >= j + 3: extmin = min(extmin, float(min(w4[j] - w4[j - 1] if j > 0 else np.inf, w4[j + 2] - w4[j + 1])))
            fr.append(vv[:, j:j + 2])
        b = fr[0]
        if bp is not None and np.linalg.det(bp.T @ b) < 0: b = b @ np.diag([1, -1]); fr[0] = b
        if b0 is None: b0 = b
        bp = b; W = np.eye(2)
        for j in range(nf2 - 1):
            M = fr[j].T @ fr[j + 1]; svmin = min(svmin, float(np.linalg.svd(M, compute_uv=False).min())); W = W @ M
        Msew = fr[-1].T @ (S2 @ fr[0]); sew = max(sew, float(abs(1.0 - np.linalg.svd(Msew, compute_uv=False).min())))
        svmin = min(svmin, float(np.linalg.svd(Msew, compute_uv=False).min())); W = W @ Msew
        u, s, vt = np.linalg.svd(W); O = u @ vt
        polar.append(float(np.linalg.det(O))); ph.append(float(np.arctan2(O[1, 0], O[0, 0])))
    ext = np.unwrap(np.append(np.unwrap(ph), ph[0]))
    return dict(e2=float((ext[-1] - ext[0]) / (2 * np.pi)), orientation_closure=float(np.linalg.det(bp.T @ (S1 @ b0))),
                min_polar_det=float(min(polar)), min_overlap_singular_value=float(svmin), max_sewing_loss=float(sew),
                max_reality_residual=float(realres), min_external_gap_meV=(None if not np.isfinite(extmin) else float(extmin)),
                mesh=[nf1, nf2], lo=lo, valley=v)
def pair_charges(m, U, nodes, r=0.012, start_offset=np.array([1.0, 0.0]), image=None):
    """Relative charge along the straight segment. `start_offset` and the periodic `image` are explicit, because a
    mirrored measurement must mirror them too (v073p finding V02)."""
    d = ((nodes[1] - nodes[0]) + 0.5) % 1 - 0.5 if image is None else np.asarray(image, float)
    off = r * np.asarray(start_offset, float) / np.linalg.norm(start_offset)
    sa = nodes[0] + off; sb = nodes[0] + d + off
    base = frame_at(m, U, m.frac_to_k(sa), m.dim // 2 - 1)[1]
    w1 = node_winding(m, U, nodes[0], r, 96, base)
    w2 = node_winding(m, U, nodes[0] + d, r, 96, transport(m, U, [sa, sb], base, nstep=300))
    return float(w1), float(w2), classify(w1, w2), dict(start_offset=list(map(float, off)), image=list(map(float, d)))
def band_sign_holonomy(m, U, band, axis, c, n=100, min_gap=1e-6):
    """Sign holonomy of one real band around a cycle, with reality enforced and degeneracy along the path refused (V04)."""
    v = int(getattr(m, 'valley', 1)); S = shift_matrix(m, (-v, 0)) if axis == 0 else shift_matrix(m, (0, -v))
    prev = first = None; gmin = np.inf
    for t in np.linspace(0, 1, n + 1):
        q = np.array([t, c]) if axis == 0 else np.array([c, t])
        w3, v3 = frame_at(m, U, m.frac_to_k(q), max(band - 1, 0), 3)
        j = band - max(band - 1, 0); gmin = min(gmin, float(min(w3[j] - w3[j - 1] if j > 0 else np.inf, w3[j + 1] - w3[j])))
        if gmin < min_gap: raise DegeneracyError(f'band {band} is degenerate along the cycle (gap {gmin:.2e} meV)')
        vv = v3[:, j:j + 1]
        if prev is not None and prev[:, 0] @ vv[:, 0] < 0: vv = -vv
        if first is None: first = vv
        prev = vv
    return float(prev[:, 0] @ (S @ first)[:, 0]), float(gmin)
