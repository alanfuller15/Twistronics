"""sparse_mode_v2.py — corrected sparse mode for the R1/atlas engines (partner v072p).

Closes the reviewed contracts F01-F06 of FABLE_NEXT_PASS.md at commit f9b7219.
Supported mode (explicit, enforced): real C2zT basis, fixed reciprocal-index set, absolute ordered bands
lo..lo+n-1 requested by index. Absolute identity is PROVED per accepted solve by two Sylvester inertia counts
bracketing the returned window; nothing is inferred from straddling a shift or from a small residual.
Every numerical check is enforced by ComparisonPolicy and retained in a Ledger; counts come from the ledger."""
import numpy as np, hashlib, json, time
import scipy.sparse as sp, scipy.sparse.linalg as spl
from scipy.linalg import eigh
from fast_engine import RealEngine
class ModeError(RuntimeError): pass
class PolicyFailure(RuntimeError): pass
class GuardFailure(RuntimeError): pass

# ---------- F05: one ledger, all work, counts derived ----------
class Ledger:
    def __init__(self): self.entries = []; self.t0 = time.perf_counter()
    def add(self, kind, **kw):
        self.entries.append(dict(kind=kind, elapsed=time.perf_counter() - self.t0, **kw)); return self.entries[-1]
    def counts(self):
        c = {}
        for e in self.entries: c[e['kind']] = c.get(e['kind'], 0) + 1
        return c
    def seconds(self, kind=None):
        return sum(e.get('seconds', 0.0) for e in self.entries if kind is None or e['kind'] == kind)
    def dump(self, path): json.dump(dict(counts=self.counts(), wall_seconds=time.perf_counter() - self.t0, entries=self.entries), open(path, 'w'), indent=1)

# ---------- F02: enforced comparison policy ----------
class ComparisonPolicy:
    """Every declared check is enforced here: nonfinite, unavailable and over-threshold all raise. The recorded
    outcome is a numerical cross-check between two computations, never a verified-arithmetic certificate."""
    def __init__(self, ledger, thresholds=None):
        self.ledger = ledger
        self.th = dict(window_vs_dense_meV=1e-10, eigen_residual=1e-8, inertia_agreement=0, offset_residual=1e-7)
        if thresholds: self.th.update(thresholds)
    def check(self, name, value, where=None, kind='numerical_cross_check'):
        """kind is recorded as `check_kind`: a numerical cross-check between two computations, not a proof"""
        th = self.th[name]
        if value is None: self.ledger.add('check_failed', check=name, reason='unavailable', where=where); raise PolicyFailure(f'{name}: comparison unavailable at {where}')
        v = float(value)
        if not np.isfinite(v): self.ledger.add('check_failed', check=name, reason='nonfinite', where=where); raise PolicyFailure(f'{name}: nonfinite at {where}')
        ok = v <= th
        self.ledger.add('check', check=name, value=v, threshold=th, passed=bool(ok), where=where, check_kind=kind)
        if not ok: raise PolicyFailure(f'{name}={v:.3e} exceeds {th:.3e} at {where}')
        return v

# ---------- F06: exact finite-model identity ----------
def validate_index_set(idx):
    """reject malformed, nonfinite, noninteger (e.g. +-1.9) and duplicate indices BEFORE assembly"""
    a = np.asarray(idx, dtype=object)
    if a.ndim != 2 or a.shape[1] != 2: raise ModeError('index_set must be a list of (m, n) pairs')
    out = []
    for r in idx:
        if len(r) != 2: raise ModeError(f'malformed index entry {r!r}')
        pair = []
        for v in r:
            fv = float(v)
            if not np.isfinite(fv): raise ModeError(f'nonfinite index component {v!r}')
            if fv != int(fv): raise ModeError(f'noninteger index component {v!r} (truncation is not allowed)')
            pair.append(int(fv))
        out.append(tuple(pair))
    if len(set(out)) != len(out): raise ModeError('duplicate indices in index_set')
    return out
def index_hash(idx): return hashlib.sha256(json.dumps([list(t) for t in idx], sort_keys=False).encode()).hexdigest()
def source_hashes(paths):
    return {p: hashlib.sha256(open(p, 'rb').read()).hexdigest() for p in paths}
class RunIdentity:
    def __init__(self, model, index_set, engine, thresholds, seeds, sources):
        self.d = dict(model=model, engine=engine, dimension=4 * len(index_set), basis_vectors=len(index_set),
                      index_sha256=index_hash(index_set), index_set=[list(t) for t in index_set],
                      thresholds=thresholds, seeds=seeds, source_sha256=sources)
    def to_dict(self): return dict(self.d)

# ---------- F01: certified sparse windows ----------
class CertifiedSparse:
    def __init__(self, m, ledger, policy):
        self.E = RealEngine(m); self.m = m; self.D = self.E.D; self.ledger = ledger; self.policy = policy
        HRs = self.E.HRs; D = self.D
        r0, c0 = np.nonzero(HRs); rows = [r0]; cols = [c0]
        for L in self.E.layers:
            i = L['idx']; rows += [i, i + 1, i, i + 1]; cols += [i, i + 1, i + 1, i]
        R = np.concatenate([np.asarray(x) for x in rows]); C = np.concatenate([np.asarray(x) for x in cols])
        S = sp.coo_matrix((np.zeros(len(R)), (R, C)), shape=(D, D)).tocsr(); S.sum_duplicates()
        rr = np.repeat(np.arange(D), np.diff(S.indptr)); S.data = HRs[rr, S.indices].copy()
        self.S = S; self.base = S.data.copy()
        def pos(r, c):
            s, e = S.indptr[r], S.indptr[r + 1]; j = s + int(np.searchsorted(S.indices[s:e], c)); assert S.indices[j] == c; return j
        self.pmap = [dict(aa=np.array([pos(x, x) for x in L['idx']]), bb=np.array([pos(x + 1, x + 1) for x in L['idx']]),
                          ab=np.array([pos(x, x + 1) for x in L['idx']]), ba=np.array([pos(x + 1, x) for x in L['idx']]), L=L) for L in self.E.layers]
        self.v0 = np.ones(D); self.I = sp.identity(D, format='csr')
    def S_k(self, k):
        d = self.base.copy(); s = self.E.valley          # V01: kinetic blocks follow the valley, as in RealEngine.HR_k
        for P in self.pmap:
            L = P['L']; pp = L['ppf'](s * np.asarray(k, float)); a = L['hv'] * pp[:, 0]; b = s * L['hv'] * pp[:, 1]
            d[P['aa']] += a; d[P['bb']] -= a; d[P['ab']] -= b; d[P['ba']] -= b
        self.S.data = d; return self.S
    def _fact(self, S, mu, where):
        """LU in symmetric mode; returns (lu, inertia_below_mu). Unavailable inertia is a policy failure."""
        t = time.perf_counter()
        lu = spl.splu((S - mu * self.I).tocsc(), diag_pivot_thresh=0.0, options=dict(SymmetricMode=True))
        d = lu.U.diagonal(); self.ledger.add('factorization', mu=float(mu), seconds=time.perf_counter() - t, where=where)
        if np.any(d == 0.0): self.policy.check('inertia_agreement', None, where=where)
        return lu, int((d < 0).sum())
    def window(self, f, lo, n=2, extra=2, mu_hint=None, where='window'):
        """Return (values, vectors) for ABSOLUTE bands lo..lo+n-1, proved by inertia counts, or raise."""
        t0 = time.perf_counter(); S = self.S_k(self.E.kc(f)); need = n + extra
        mu = float(mu_hint) if mu_hint is not None else 0.0
        lu = nu = None
        for _ in range(60):                                   # move mu until exactly `lo` eigenvalues lie below it
            lu, nu = self._fact(S, mu, where)
            if nu == lo: break
            step = max(1.0, abs(mu) * 0.5 + 1.0) * (1 if nu < lo else -1); mu += step
        if nu != lo:
            self.ledger.add('rejected', where=where, reason=f'could not place mu with inertia {lo} (last {nu})'); raise ModeError(f'{where}: no shift with exactly {lo} eigenvalues below it')
        op = spl.LinearOperator((self.D, self.D), matvec=lu.solve, dtype=float)
        above = []; k = min(2 * need + 2, self.D - 1)
        while True:                                            # grow the request until the certified side is covered
            w, V = spl.eigsh(S, k=k, sigma=mu, which='LM', OPinv=op, v0=self.v0, tol=0)
            o = np.argsort(w); w, V = w[o], V[:, o]; above = np.where(w > mu)[0]
            self.ledger.add('arpack_request', where=where, k=int(k), above=int(len(above)))
            if len(above) >= n + 1 or k >= self.D - 1: break
            k = min(2 * k, self.D - 1)
        if len(above) < n + 1:
            self.ledger.add('rejected', where=where, reason='window does not contain the requested bands plus a neighbour'); raise ModeError(f'{where}: insufficient eigenvalues above the certified shift')
        sel = above[:n]; wv, Vv = w[sel], V[:, sel]
        mu_hi = 0.5 * (wv[-1] + w[above[n]])
        lu2, nu_hi = self._fact(S, mu_hi, where)
        if nu_hi != lo + n:
            self.ledger.add('rejected', where=where, reason=f'top-edge inertia {nu_hi} != {lo + n}'); raise ModeError(f'{where}: the returned set is not contiguous bands {lo}..{lo + n - 1}')
        res = float(max(np.linalg.norm(S @ Vv[:, j] - wv[j] * Vv[:, j]) for j in range(n)))
        self.policy.check('eigen_residual', res, where=where)
        self.ledger.add('sparse_solve', where=where, lo=int(lo), n=int(n), mu=float(mu), residual=res, seconds=time.perf_counter() - t0)
        return wv, Vv, float(wv[0])
    def dense_window(self, f, lo, n=2, where='dense'):
        t = time.perf_counter(); w, V = eigh(self.E.HR(f), subset_by_index=(lo, lo + n - 1))
        self.ledger.add('dense_solve', where=where, lo=int(lo), n=int(n), seconds=time.perf_counter() - t); return w, V
    def compare_with_dense(self, f, lo, n=2, where='recert'):
        ws, _, _ = self.window(f, lo, n, where=where); wd, _ = self.dense_window(f, lo, n, where=where)
        return self.policy.check('window_vs_dense_meV', float(np.abs(ws - wd).max()), where=where)
    # ---------- F04: exhausted Newton returns its own coordinate and a gap evaluated there ----------
    def newton_node(self, f0, lo, maxit=40, tol=1e-11, trust=0.02, ext_min=1e-5, where='newton', recert_every=0):
        f = np.array(f0, float); mu_hint = None; hist = []
        for it in range(maxit):
            w4, V4, low = self.window(f, lo - 1, 4, mu_hint=mu_hint, where=where); mu_hint = low - 1.0
            wp = w4[1:3]; Fp = V4[:, 1:3]; g = float(wp[1] - wp[0]); ext = float(min(wp[0] - w4[0], w4[3] - wp[1]))
            hist.append(dict(it=it, f=f.tolist(), gap=g, ext=ext))
            if recert_every and it % recert_every == 0: self.compare_with_dense(f, lo - 1, 4, where=where + ':recert')
            if ext < ext_min: return dict(converged=False, reason='pair not isolated', f=f.tolist(), gap=g, ext=ext, iterations=it + 1, hist=hist)
            if g < tol: return dict(converged=True, f=f.tolist(), gap=g, ext=ext, iterations=it + 1, hist=hist)
            A = [self.E.dHR_proj(Fp, a) for a in (0, 1)]
            J = np.array([[(A[0][0, 0] - A[0][1, 1]) / 2, (A[1][0, 0] - A[1][1, 1]) / 2], [A[0][0, 1], A[1][0, 1]]])
            try: step = np.linalg.solve(J, -np.array([(wp[0] - wp[1]) / 2, 0.0]))
            except np.linalg.LinAlgError:
                return dict(converged=False, reason='singular Jacobian', f=f.tolist(), gap=g, ext=ext, iterations=it + 1, hist=hist)
            nrm = np.linalg.norm(step); f = f + (step * trust / nrm if nrm > trust else step)
        w4, _, _ = self.window(f, lo - 1, 4, mu_hint=mu_hint, where=where)      # gap AT the returned coordinate
        return dict(converged=False, reason='maxit', f=f.tolist(), gap=float(w4[2] - w4[1]), ext=float(min(w4[1] - w4[0], w4[3] - w4[2])), iterations=maxit, hist=hist)
