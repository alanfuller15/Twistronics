"""Assertions for the valley variant and the chiral control, including the v073p review findings (partner v074p)."""
import numpy as np, pytest
from bm_strain import BM, HBARV
from gate import real_basis
from fast_engine import RealEngine
from sparse_mode_v2 import CertifiedSparse, Ledger, ComparisonPolicy
from topo import euler_wilson, band_sign_holonomy, frame_at, RealityError
def test_valley_is_the_exact_time_reversal_partner():
    kw = dict(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact')
    K, P = BM(valley=+1, **kw), BM(valley=-1, **kw); k = K.frac_to_k(np.array([0.31, 0.27]))
    assert np.array_equal(P.H(k), np.conj(K.H(-k)))
    assert np.abs(P.bands_near_zero(k, 3) - K.bands_near_zero(-k, 3)).max() == 0.0
def test_valley_rejects_bad_input():
    with pytest.raises(ValueError): BM(N=3, valley=0)
@pytest.mark.parametrize('v', [+1, -1])
def test_V01_fast_and_sparse_engines_follow_the_valley(v):
    """v073p V01: the fast engine assembled the K matrix for a K' model; both paths must now match the native one."""
    m = BM(N=4, eps=0.003, kinetic='lab_nn_full', geometry='exact', valley=v); U = real_basis(m.nG); E = RealEngine(m)
    led = Ledger(); C = CertifiedSparse(m, led, ComparisonPolicy(led))
    for f in ([0.31, 0.27], [0.11, 0.43], [-0.31, -0.27]):
        k = m.frac_to_k(np.array(f)); dense = U.conj().T @ m.H(k) @ U
        assert np.abs(dense.imag).max() < 1e-9
        assert np.abs(dense.real - E.HR_k(k)).max() < 1e-10
        assert np.abs(E.bands(np.array(f), 3) - m.bands_near_zero(k, 3)).max() < 1e-10
        w, _, _ = C.window(np.array(f), m.dim // 2 - 3, 6, where='test')
        assert np.abs(np.sort(w) - m.bands_near_zero(k, 3)).max() < 1e-10
def test_V04_non_real_model_is_refused_by_the_frame_path():
    m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact', mass=1.0); U = real_basis(m.nG)
    with pytest.raises(RealityError): frame_at(m, U, m.frac_to_k(np.array([0.31, 0.27])), m.dim // 2 - 1)
    with pytest.raises(RealityError): band_sign_holonomy(m, U, m.dim // 2 - 1, 0, 0.0, n=8)
def test_V05_band_selection_is_honoured_and_out_of_range_is_refused():
    m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact'); U = real_basis(m.nG)
    with pytest.raises(ValueError): euler_wilson(m, U, lo=999, nf1=6, nf2=8)
    d = euler_wilson(m, U, lo=m.dim // 2 - 1, nf1=8, nf2=12); assert d['lo'] == m.dim // 2 - 1
def test_V03_diagnostics_are_named_for_what_they_are():
    m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact'); U = real_basis(m.nG)
    d = euler_wilson(m, U, nf1=10, nf2=16)
    for key in ('min_polar_det', 'min_overlap_singular_value', 'max_sewing_loss', 'max_reality_residual', 'min_external_gap_meV'):
        assert key in d
    assert 'min_det' not in d and d['min_overlap_singular_value'] <= 1.0 and abs(abs(d['e2']) - 1) < 0.05
def test_chiral_limit_sublattice_symmetry_and_alpha_at_the_sampled_minimum():
    m = BM(N=4, theta_deg=1.06, ratio=0.0, eps=0.0, kinetic='none')
    w = np.linalg.eigvalsh(m.H(m.frac_to_k(np.array([0.31, 0.27]))))
    assert np.abs(w + w[::-1]).max() < 1e-8
    assert abs(m.w1 / (HBARV * m.ktheta) - 0.586) < 0.01     # sampled bracket, not an accuracy claim
