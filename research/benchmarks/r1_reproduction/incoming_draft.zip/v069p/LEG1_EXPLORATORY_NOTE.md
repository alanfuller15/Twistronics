# R1 leg 1 — exploratory subset (partner, ungated; N=4, lab_nn_full, exact geometry, theta=1.05°, D=0, P=1)

Not an accepted run. Purpose: settle the decision the plan needed and hand the team a leg-1 method that cannot mistake a relabelling for a crossing.

## Decision taken
The displacement field is implemented as the literal uniform layer-antisymmetric term (`Dfield`, meV, +D on layer 1, −D on layer 2), checked C₂zT-real in the gate basis; the cos-harmonic layer-antisymmetric potential stays as a named variant. `bm_strain.py` in this folder carries it; nothing else in the engine changed.

## Grid snapshots are not enough
On the (ε, φ) grid the flat pair's two roots come back in search order, and that order swapped between ε=0.55 % and 0.60 % at φ=45°. Every segment offset then flips sign and t → 1−t, which looks exactly like an interior crossing. It is not. Leg 1 must be run as paths with node identities carried by nearest-assignment continuity (`rk_path.py`); the grid version (`rk_leg1.py`) is kept only to show the artifact.

## Tracked paths (ε from 0.45 % to 0.65 % in 0.05 % steps)

| φ | node | t at ends | offset at ends | reading |
|---|---|---|---|---|
| 45° | U0 | 0.81 → 0.60 (inside) | −0.106 → −0.141 | inside the span, moving away: no crossing |
| 45° | U1 | 1.55 → 1.56 (beyond end) | −0.030 → +0.073 | crosses the line extension at ε≈0.52 %: **not a braid** |
| 45° | L0 | −0.46 → −0.55 (beyond start) | +0.049 → −0.049 | crosses the extension at ε≈0.55 %: **not a braid** |
| 45° | L1 | 0.07 → 0.33 (inside) | +0.097 → +0.132 | moving away |
| 30° | U0 | −0.24 → −0.23 (beyond start) | +0.027 → −0.044 | crosses the extension at ε≈0.50 %: not a braid |
| 30° | U1 | 0.07 → 0.20 (inside) | +0.076 → +0.093 | moving away |
| 30° | L0 | 1.22 → 1.23 (beyond end) | −0.021 → +0.033 | crosses the extension at ε≈0.54 %: not a braid |
| 30° | L1 | 0.96 → 0.89 (inside) | −0.071 → −0.080 | moving away |

Closest interior approach on these two paths: 0.071 (φ=30°, L1 at ε=0.60 %). Under the plan's candidate rule (|offset| < 0.02 with 0 < t < 1) there is **no candidate** on either path. Every sign change found sits beyond an endpoint. The same pattern held in the φ=0 and 60° grid cells (adjacent nodes outside the span or at |offset| ≥ 0.07).

## What this changes in the plan
- Leg 1 is executed as φ-indexed ε-paths with tracked identities, not as a grid; the candidate rule is applied per path.
- The stop rule stands: no candidate with |offset| < 0.05 on the paths run so far. The paths run cover φ ∈ {30°, 45°} fully and φ ∈ {0°, 15°, 60°} as snapshots; φ from 75° to 180° and the θ, D, P dials are untouched. A negative result for strain-only braiding at θ=1.05° would need the remaining φ paths, and the plan's legs 3–4 dials remain the way to change that answer.
- Model note for any magnitude quoted from these files: bandwidth 29–47 meV over 0.45–0.65 % strain; all values N=4, constant tunnelling, D=0.

## Files
`rk_probe.py` (state probe), `rk_leg1.py` (grid, artifact-bearing), `rk_path.py` (tracked paths), `rk_path_phi30.json`, `rk_path_phi45.json`, `rk_leg1_*.json`, `bm_strain.py` (Dfield), `PLAN_realizable_knobs.md`, `NUMERICAL_PLAN_R1_draft.json`.

## Leg 1 completed (strain-only, exploratory, N=4) — negative within bounds

Paths with tracked identities at φ = 0°, 15°, 30°, 45° (the independent range under C₃; φ = 60°, 75°, 90° checked as images: 75° isolated to 0.65 % like 15°, 90° reproduces 30°). Remote closing: ε_c ≈ 0.40 % (φ=0°), between 0.60 and 0.70 % (φ=15°), ≈ 0.45 % (30°), ≈ 0.45 % (45°); φ=15°/75° is the hard direction. Closest interior approach within the declared bound ε ≤ 0.7 %: **0.069** (φ=15°, ε=0.7 %, U0 at t=0.30); at ε=0.8 %, outside the bound, 0.052. Every sign change on every path is a line-extension crossing beyond an endpoint. **No candidate under the pre-registered rule; strain-only braiding at θ=1.05° is negative at N4.**

## Leg 1b probe (one dial at a time from the closest strain-only approach, ε=0.6 %, φ=30°, closest interior 0.071)

| dial | values | closest interior approach | reading |
|---|---|---|---|
| D (literal field, meV) | −30 … +30 | 0.086–0.095 (D<0), 0.073–0.075 (D>0) | monotone away; the field pushes the adjacent nodes off the segment, not onto it |
| θ (deg) | 0.97, 1.00, 1.05, 1.10, 1.15 | 0.106, 0.097, 0.071, none (nodes leave the span), isolated at 1.15 | away in both directions; the non-isolated regime narrows above 1.10° |
| P (w scale) | 0.9, 1.0, 1.15, 1.3 | isolated at 0.9; 0.071; 0.104; none in span at 1.3 | away |

No single dial reduces the approach below 0.07 from this base. Pairwise combinations and the other φ bases are the remaining leg-1b work; none has been run. Every value above is N=4, ungated, constant tunnelling, and carries the bandwidth caveat (29–47 meV over the strain range).

## Where R1 stands
Strain-only: negative at N4 within bounds. Single-dial leg 1b from the best strain-only base: no improvement. Open: pairwise dials, the φ=15°/45° bases, and the accepted (gated, two-engine, N4/N6) execution of whichever of these the team freezes. A clean negative for the whole realizable set would say that the braids of the main campaign require a sublattice-odd perturbation the declared dials do not provide — itself a result, and one the plan was written to allow.
