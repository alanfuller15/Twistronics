"""Exploratory leg-1 subset (partner, ungated): (eps, phi) states with the literal Dfield=0, theta=1.05, P=1. Records flat pair,
remote gap, adjacent nodes and segment offsets; flags crossing candidates (|offset|<0.02, 0<t<1)."""
import numpy as np, sys, json, time
from rk_probe import probe
eps=[float(x) for x in sys.argv[1].split(',')]; phis=[int(x) for x in sys.argv[2].split(',')]; out=[]
for e in eps:
    for p in phis:
        t=time.time(); r=probe(eps=e,phi=p); out.append(r)
        cands=[(lab,round(a,2),round(b,4)) for lab in ('upper','lower') for a,b in r.get(lab+'_offsets',[]) if 0<a<1 and abs(b)<0.02]
        near=[(lab,round(a,2),round(b,4)) for lab in ('upper','lower') for a,b in r.get(lab+'_offsets',[]) if 0<a<1]
        print(f"eps={e:.4f} phi={p:3d}: flat {r['n_flat']} remote {r['min_remote']:.3f} up {len(r['upper'])} lo {len(r['lower'])} | in-segment {near} | CANDIDATE {cands if cands else '-'} ({time.time()-t:.0f}s)"); sys.stdout.flush()
json.dump(out,open(f'rk_leg1_{sys.argv[1].replace(",","_")}.json','w'),indent=1)
