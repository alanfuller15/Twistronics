"""Leg-1 as PATHS (partner, ungated): at fixed phi, step eps upward carrying node identities by nearest assignment
(flat pair order fixed by continuity; adjacent nodes matched to previous positions). Offsets are then comparable
between states, and a segment-interior sign change with t staying inside (0,1) is a crossing candidate."""
import numpy as np, sys, json, time
from rk_probe import mk
from bm_strain import frac_dist, segment_geometry
from braid import adjacent_nodes
def match(prev, cur):
    """assign cur nodes to prev identities by nearest periodic distance; returns list aligned with prev (None if lost) + new"""
    out=[None]*len(prev); used=set()
    for i,p in enumerate(prev):
        j=min((frac_dist(p,c),k) for k,c in enumerate(cur) if k not in used)[1] if len(used)<len(cur) else None
        if j is not None and frac_dist(prev[i],cur[j])<0.08: out[i]=cur[j]; used.add(j)
    new=[c for k,c in enumerate(cur) if k not in used]
    return out,new
if __name__=='__main__':
    phi=float(sys.argv[1]); eps_list=[float(x) for x in sys.argv[2].split(',')]
    flat=None; ups=[]; los=[]; rows=[]
    for e in eps_list:
        t=time.time(); m=mk(eps=e,phi=phi); fl=[f for v,f in m.find_nodes(ngrid=24,nkeep=10) if v<1e-6]; adj=adjacent_nodes(m,ngrid=24)
        U=[f for _,f in adj['+']]; L=[f for _,f in adj['-']]
        if flat is None or len(fl)!=2: flat=fl if len(fl)==2 else flat
        else:
            a,_=match(flat,fl); 
            if all(x is not None for x in a): flat=a
        ups,newU=match(ups,U) if ups else ([],U); ups=[u for u in ups if u is not None]+newU
        los,newL=match(los,L) if los else ([],L); los=[l for l in los if l is not None]+newL
        geo=lambda q: segment_geometry(flat[0],flat[1],q)[:2]
        ug=[geo(u) for u in ups]; lg=[geo(l) for l in los]
        rows.append(dict(eps=e,phi=phi,flat=[f.tolist() for f in flat],upper=[u.tolist() for u in ups],lower=[l.tolist() for l in los],upper_geo=ug,lower_geo=lg,min_remote=float(m.min_remote(ngrid=15,nkeep=3)[0])))
        print(f"phi={phi:.0f} eps={e:.4f}: flat {tuple(np.round(flat[0],3))}-{tuple(np.round(flat[1],3))} | U (t,off) {[(f'U{i}',round(a,2),round(b,4)) for i,(a,b) in enumerate(ug)]} | L {[(f'L{i}',round(a,2),round(b,4)) for i,(a,b) in enumerate(lg)]} ({time.time()-t:.0f}s)"); sys.stdout.flush()
    json.dump(rows,open(f'rk_path_phi{int(phi)}.json','w'),indent=1)
