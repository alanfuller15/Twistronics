"""Feasibility probe for the realizable-knob campaign (partner v069p draft). Physical dials only:
eps (heterostrain), phi (direction), theta (twist), D (interlayer displacement field = layer-antisymmetric scalar, C2zT-preserving),
wscale (pressure: w0,w1 scaled together). Model: lab_nn_full, exact geometry, N=4. For each state: flat-pair roots and label,
min remote gap, adjacent-gap nodes and their (t, offset) relative to the flat pair's segment. Exploratory; no gate acceptance."""
import numpy as np, sys, json, time
from bm_strain import BM, frac_dist, segment_geometry, s0
from knobs import add_harmonic
from braid import adjacent_nodes
def mk(eps=0.003, phi=0.0, theta=1.05, D=0.0, wscale=1.0):
    m = BM(N=4, theta_deg=theta, w1=110.0*wscale, ratio=0.8, eps=eps, phi_deg=phi, kinetic='lab_nn_full', geometry='exact')
    if D: add_harmonic(m, D, mat=s0, layer_sign=-1)          # cos harmonics of a layer-antisymmetric scalar (declared proxy for D)
    return m
def probe(**kw):
    m = mk(**kw); fn = lambda f: m.gaps(m.frac_to_k(f))[0]
    fl = [f for v, f in m.find_nodes(ngrid=24, nkeep=10) if v < 1e-6]
    rem = m.min_remote(ngrid=15, nkeep=4); adj = adjacent_nodes(m, ngrid=24)
    rec = dict(state=kw, n_flat=len(fl), flat=[f.tolist() for f in fl], min_remote=float(rem[0]), upper=[f.tolist() for _, f in adj['+']], lower=[f.tolist() for _, f in adj['-']], bw=float(m.flat_bandwidth(8)))
    if len(fl) == 2:
        for lab, lst in (('upper', adj['+']), ('lower', adj['-'])):
            rec[lab + '_offsets'] = [list(segment_geometry(fl[0], fl[1], q)[:2]) for _, q in lst]
    return rec
if __name__ == '__main__':
    out = []
    grid = [dict(eps=e, phi=p) for e in (0.004, 0.005, 0.006) for p in (0, 30, 60, 90)]
    for kw in grid:
        t = time.time(); r = probe(**kw); out.append(r)
        segs = [(round(a, 2), round(b, 3)) for a, b in r.get('upper_offsets', [])] + [('L', round(a, 2), round(b, 3)) for a, b in r.get('lower_offsets', [])]
        print(f"eps={kw['eps']:.3f} phi={kw['phi']:3d}: flat nodes {r['n_flat']} | min remote {r['min_remote']:.3f} meV | upper {len(r['upper'])} lower {len(r['lower'])} | offsets(t,off) {segs} | bw {r['bw']:.0f} ({time.time()-t:.0f}s)"); sys.stdout.flush()
    json.dump(out, open('rk_probe_eps_phi.json', 'w'), indent=1)
