# Complementary campaign R1 — Realizable-knob braiding (partner draft v069p, for team freezing)

Status: DRAFT for the team to freeze in its format before any accepted run. Nothing here is a result. The feasibility probe attached (`rk_probe.py`, N=4, exploratory, ungated) exists only to make leg 1 a bounded task rather than a hope.

## Question
Can the two C₂zT-preserving braids that removed the flat pair's Euler obstruction (v026–v033; every leg gate-accepted in both engines, v042–v067) be produced using only parameters that correspond to physical controls on a strained twisted bilayer? A clean negative answer (no braid anywhere in the realizable set within stated bounds) is a result of equal value.

## Declared knob set (and nothing else)
| symbol | physical control | model implementation | bounds |
|---|---|---|---|
| ε | heterostrain magnitude | `eps` (E_l = ∓E/2, lab frame) | 0.1 % – 0.7 % |
| φ | heterostrain direction | `phi_deg` | 0 – 180° |
| θ | twist angle | `theta_deg` | 0.95 – 1.20° |
| D | interlayer displacement field | **literal uniform layer-antisymmetric potential** `Dfield` (meV), implemented identically in both engines (decision taken, LEG1_EXPLORATORY_NOTE.md); the cos-harmonic variant is retained as a named alternative | ±33 meV in the draft; **revision to ±50 meV proposed** after LEG2_CANDIDATE_NOTE.md, to be justified by a checked reference before freezing |
| P | pressure | `wscale`: w₀ and w₁ scaled together, ratio fixed at 0.8 | 0.9 – 1.3 |

Excluded from the braid search: the hBN-alignment sublattice mass (breaks C₂zT; retained as the declared exit control, v023 §6), all sublattice-odd harmonics (sin·σ_z, τ_zσ_z), the scalar moiré harmonic A, and any change of ratio w₀/w₁ (corrugation is not a dial). Model: `kinetic='lab_nn_full'`, exact geometry in both engines (`cutoff_tol` named), constant tunnelling under `w_mode='average'` with κ=0; strain-dependent tunnelling stays the named approximation as in v048 §2.

## Pre-registered criteria
- **Braid event:** the flat pair's straight-segment relative charge changes SAME→OPPOSITE across an interval in which an adjacent-gap node is seen to cross the segment interior (0 < t < 1) with the pair isolated on both sides of the interval; measured by the team's spatial-transport gate with mesh/radius agreement, both engines, N4 and N6, exactly as in v037/v044.
- **Not a braid:** a node passing beside an endpoint (t outside (0,1)), a crossing of the line extension, a label change with the pair non-isolated at both comparison stations, or any event only one engine reports.
- **Negative result:** every bounded 1-D path in the knob set from the isolated baseline that reaches the non-isolated regime is traced to its bound without a braid event, at N4, with the closest approach (min |offset| for t in (0,1)) tabulated per path.
- Magnitudes are model-internal and carry the model tag; no physical claim of any kind.

## Legs
1. **(ε, φ) map at θ=1.05°, D=0, P=1.** Locate the remote-closing curve ε_c(φ) (U-pair birth); track the flat pair and every adjacent-gap node on a grid ε∈{0.30…0.70 %} × φ∈{0…180° by 15°}; tabulate segment offsets. Output: the set of (ε, φ) cells where an adjacent node has |offset| < 0.02 with t∈(0,1) — the crossing candidates. Feasibility probe: at N=4 the remote gap closes by ε=0.4 % (φ=0), and at ε=0.5–0.6 %, φ=30° adjacent nodes are within 0.002–0.03 of the segment (`rk_probe_eps_phi.json`).
2. **Crossing candidates → braid test.** For each candidate, a 1-D fine path (in ε or φ) with two-seed root tracking and the spatial gate at both ends and across the interval; both engines, N4 then N6.
3. **Second dial for the un-linking and closing.** Where leg 2 yields a braid, use D and θ to un-link (v028's role of B_τ) and to drive the opposite pair together (v029's role); each with the fold diagnostics of v042.
4. **Second braid and endpoint** only if leg 3 closes the first pair; otherwise stop and report the negative result with the closest approaches.

## Stop rules and budget
Each leg is a frozen plan with its own hash before execution; no threshold relaxed after results; every rejected run retained.
**Amendment (partner, before any accepted run):** the original stop rule ("no candidate in leg 1 → do not proceed") ended the campaign after one of five dials. Corrected: leg 1 is strain-only (ε, φ at θ=1.05°, D=0, P=1) and its negative closes strain-only braiding at N4; **leg 1b** then searches the other dials (D, θ, P, each as one-parameter paths from the closest strain-only approaches, and pairwise where a single dial reduces the approach). The campaign's negative result is declared only when leg 1b is exhausted within bounds. By C₃ (v024 §1: φ and φ+60° are images), leg 1's independent range is φ ∈ [0°, 60°), which cuts the grid threefold; leg 1 must be run as φ-indexed ε-paths with node identities carried by continuity, because grid snapshots cannot distinguish a crossing from a relabelling (LEG1_EXPLORATORY_NOTE.md).

## What this campaign does not duplicate
The completed campaign's route and its acceptance work are untouched; the harness, engines, gates and evidence recorder are reused as-is. New here is only the parameter set and the question.

## Open decision for the inventor
The D proxy: cos-harmonic layer-antisymmetric potential (existing knob) vs a uniform τ_z term (the literal field). Recommend implementing the literal term and keeping the harmonic as a named variant; the plan cannot be frozen until one is chosen. The physical acceptance target (v056 §3) remains PROPOSAL and this campaign does not depend on it.
