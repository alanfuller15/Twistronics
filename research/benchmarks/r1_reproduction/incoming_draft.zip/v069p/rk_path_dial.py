"""Tracked-identity path along one physical dial (partner, ungated). Node identities carried by nearest assignment;
offsets comparable between states; a segment-interior sign change with t staying inside (0,1) is a crossing candidate."""
import numpy as np, sys, json, time, os
from rk_dials import mk2, BASE
from rk_path import match
from bm_strain import frac_dist, segment_geometry
from braid import adjacent_nodes
dial=sys.argv[1]; vals=[float(x) for x in sys.argv[2].split(',')]
FIX={k:float(v) for k,v in (kv.split('=') for kv in os.environ.get('RK_FIX','').split(',') if kv)}
flat=None; ups=[]; los=[]; rows=[]
for v in vals:
    t=time.time(); kw=dict(FIX); kw[dial]=v; m=mk2(**kw)
    fl=[f for q,f in m.find_nodes(ngrid=24,nkeep=10) if q<1e-6]; adj=adjacent_nodes(m,ngrid=24); U=[f for _,f in adj['+']]; L=[f for _,f in adj['-']]
    if flat is None or len(fl)!=2: flat=fl if len(fl)==2 else flat
    else:
        a,_=match(flat,fl)
        if all(x is not None for x in a): flat=a
    ups,newU=match(ups,U) if ups else ([],U); ups=[u for u in ups if u is not None]+newU
    los,newL=match(los,L) if los else ([],L); los=[l for l in los if l is not None]+newL
    geo=lambda q: segment_geometry(flat[0],flat[1],q)[:2]; ug=[geo(u) for u in ups]; lg=[geo(l) for l in los]
    rows.append(dict(fix=FIX,dial=dial,value=v,base=BASE,flat=[f.tolist() for f in flat],upper=[u.tolist() for u in ups],lower=[l.tolist() for l in los],upper_geo=ug,lower_geo=lg))
    print(f"{FIX} {dial}={v:g}: U {[(f'U{i}',round(a,2),round(b,4)) for i,(a,b) in enumerate(ug)]} | L {[(f'L{i}',round(a,2),round(b,4)) for i,(a,b) in enumerate(lg)]} ({time.time()-t:.0f}s)"); sys.stdout.flush()
json.dump(rows,open(f'rk_pathdial_{dial}_{"_".join(f"{k}{v:g}" for k,v in FIX.items()) or "base"}_phi{int(BASE["phi"])}_eps{BASE["eps"]}.json','w'),indent=1)
