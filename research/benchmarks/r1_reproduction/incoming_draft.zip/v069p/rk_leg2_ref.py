import numpy as np, sys, json
from tbg_ref import TBG
from bm_strain import frac_dist
seeds=[np.array([0.4779,0.7396]),np.array([0.8769,0.589])]; out=[]
for D in [float(x) for x in sys.argv[1:]]:
    m=TBG(N=4,theta=1.00,eps=0.007,phi=15,kinetic='lab_nn_full',Dfield=D); U=m.real_basis(); lo=m.dim//2-1
    p=[m.refine(s,m.flat_gap)[0] for s in seeds]; g=[m.flat_gap(x) for x in p]
    w1,w2,lab=m.relative_charge(U,p[0],p[1],lo)
    ext=min(m.remote_gap(p[0]+s*(((p[1]-p[0])+0.5)%1-0.5)) for s in np.linspace(0.02,0.98,49))
    out.append(dict(D=D,flat=[x.tolist() for x in p],gaps=g,w=[w1,w2],label=lab,smin=float(m.last_smin),min_exterior_gap_on_segment=float(ext)))
    print(f"ref D={D:g}: flat {tuple(np.round(p[0],4))} {tuple(np.round(p[1],4))} gaps {g[0]:.0e},{g[1]:.0e} | charges {w1},{w2} -> {lab} (frame overlap {m.last_smin:.3f}) | min exterior gap on segment {ext:.4f} meV"); sys.stdout.flush()
json.dump(out,open('rk_leg2_charge_ref.json','w'),indent=1)
