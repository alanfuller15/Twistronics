"""Leg 2 charge stations (partner, ungated, bm engine): flat pair straight-segment relative charge before and after the
candidate crossing/annihilation on the D path (phi=15, eps=0.7%, theta=1.00, N=4)."""
import numpy as np, sys, json
from rk_dials import mk2
from bm_strain import frac_dist
from braid import node_winding, transport
from euler import real_frame
from gate import real_basis, classify
seeds=[np.array([0.4779,0.7396]),np.array([0.8769,0.589])]; out=[]
for D in [float(x) for x in sys.argv[1:]]:
    m=mk2(theta=1.0,D=D); ff=lambda f: m.gaps(m.frac_to_k(f))[0]
    F=[m.refine(s,ff,return_result=True) for s in seeds]; p=[r[0] for r in F]; g=[r[1] for r in F]
    U=real_basis(m.nG); d=((p[1]-p[0])+0.5)%1-0.5; r=0.012; sa=p[0]+np.array([r,0]); sb=p[0]+d+np.array([r,0]); base=real_frame(m,U,m.frac_to_k(sa))
    w1=node_winding(m,U,p[0],r,96,base); w2=node_winding(m,U,p[0]+d,r,96,transport(m,U,[sa,sb],base,nstep=300))
    lab=classify(w1,w2); rem=m.min_remote(ngrid=15,nkeep=3)[0]
    # exterior gap along the straight segment (isolation of the comparison path)
    ext=min(m.gaps(m.frac_to_k(p[0]+s*d))[1] for s in np.linspace(0.02,0.98,49))
    out.append(dict(D=D,flat=[x.tolist() for x in p],gaps=g,w=[w1,w2],label=lab,min_remote_global=float(rem),min_exterior_gap_on_segment=float(ext)))
    print(f"D={D:g}: flat {tuple(np.round(p[0],4))} {tuple(np.round(p[1],4))} gaps {g[0]:.0e},{g[1]:.0e} | w {w1:+.3f},{w2:+.3f} -> {lab} | min exterior gap on segment {ext:.4f} meV (global remote min {rem:.3f})"); sys.stdout.flush()
json.dump(out,open('rk_leg2_charge.json','w'),indent=1)
