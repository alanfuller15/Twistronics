# R1 leg 2 — a braid candidate with a physical dial (partner, exploratory, ungated, N=4)

State: heterostrain 0.7 % at φ=15°, twist θ=1.00°, pressure P=1, `kinetic='lab_nn_full'`, exact geometry, constant tunnelling; dial: the literal interlayer displacement field D (uniform ±D on the two layers, C₂zT-preserving), implemented identically in both engines this entry.

## How it was found
Leg 1 (strain only) was negative; leg 1b single dials from the φ=15° base reduced the closest interior approach (0.069 → 0.048 field, 0.043 twist, 0.045 pressure), and the combination θ=1.00° with D≈40 meV gave 0.010. A tracked D-path then replaced closest-in-span numbers with identities.

## The event (bm engine, two-seed tracking, D in 1 meV steps)

| D (meV) | tracked upper node A (t, offset) | upper node B (t, offset) | note |
|---|---|---|---|
| 34 | (0.719, +0.0111) | — | B not yet resolved by the box |
| 35 | (0.720, +0.0089) | (0.857, −0.0354) | |
| 36 | (0.721, +0.0064) | (0.845, −0.0342) | |
| 37 | (0.722, +0.0036) | (0.832, −0.0326) | |
| 38 | (0.725, **+0.0003**) | (0.817, −0.0306) | |
| 39 | (0.730, **−0.0038**) | (0.799, −0.0277) | A has crossed the segment interior |
| 40 | (0.740, −0.0102) | (0.775, −0.0225) | |
| 41, 42 | none within 0.06; box minimum 0.14 / 0.36 meV | | A and B annihilated, both on the far side |

Node A crosses the flat pair's straight segment at D ≈ 38.1 meV with t ≈ 0.725 (interior). It then annihilates with node B between D = 40 and 41 without re-crossing. The earlier "disappearance at D = 32" was the global search losing a narrowing cone (box minimum 0.17 meV), not an event; the dense box found A at every D.

## The measurement (flat pair, straight-segment relative charge, both engines)

| D (meV) | bm windings | bm label | ref charges | ref label | min exterior gap on the segment (meV) |
|---|---|---|---|---|---|
| 30 | +0.997, +0.996 | SAME | +1, +1 | SAME | 1.4632 |
| 36 | +0.996, +0.995 | SAME | +1, +1 | SAME | 0.5328 |
| 42 | −0.994, +0.994 | **OPPOSITE** | −1, +1 | **OPPOSITE** | 0.6101 |
| 45 | +0.994, −0.994 | OPPOSITE | −1, +1 | OPPOSITE | 0.2360 |

Flat roots agree between engines to 10⁻⁴ at every station; ref frame overlap 0.978–0.979. The label changes across the interval in which a tracked adjacent-gap node crosses the segment interior, with the comparison segment isolated at every station. **This meets the plan's pre-registered braid criterion at N=4, single harness, ungated.** It is the first braid of the project produced with dials that correspond to physical controls: strain, twist angle and a displacement field.

## What it is not, yet
- Not accepted: no fold diagnostics, no mesh/radius trials, no N6, no frozen plan hash. Those are the team's gate (leg 2 proper).
- D = 38–45 meV exceeds the draft plan's ±33 meV bound. Either the bound is revised before the accepted run, with the physical justification recorded (gate-induced interlayer potential differences of this size are reported for graphene bilayers; the reference for that number must be checked, not assumed), or the crossing must be found within the bound by moving θ or ε.
- The same limits as the main campaign: constant tunnelling, N=4 bandwidth caveat (≈ 40 meV here), sampled states.
- Only the first braid. The un-linking, closing, second braid and endpoint under physical dials are legs 3–4 and untouched.

## Files
`rk_path_dial.py`, `rk_leg2_track.py` (+ `_D.json/.txt`), `rk_leg2_charge.py` / `rk_leg2_ref.py` (+ JSON/txt), `tbg_ref.py` and `bm_strain.py` with `Dfield`, the leg-1b dial records.
