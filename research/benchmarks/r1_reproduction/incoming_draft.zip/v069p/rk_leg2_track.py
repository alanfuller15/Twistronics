"""Leg 2 (partner, ungated): two-seed tracking of the upper-gap roots near the flat segment through D=34..40 meV at
phi=15, eps=0.7%, theta=1.00 (N=4, bm, lab_nn_full, exact). Also tracks the flat pair. Records (t, offset) per identity."""
import numpy as np, json, sys
from rk_dials import mk2
from bm_strain import frac_dist, segment_geometry
def roots(m,fn,c,R=0.06,n=25):
    pts=sorted((fn(np.array([a,b])),a,b) for a in np.linspace(c[0]-R,c[0]+R,n) for b in np.linspace(c[1]-R,c[1]+R,n)); ex=[]
    for v,a,b in pts[:10]:
        f,val=m.refine(np.array([a,b]),fn)
        if val<1e-6 and all(frac_dist(f,g)>1e-3 for g in ex): ex.append(f)
    return ex,pts[0][0]
flat=[np.array([0.4779,0.7396]),np.array([0.8769,0.589])]; center=np.array([0.7709,0.6469]); rows=[]
for D in [34,35,36,37,38,39,40,41,42]:
    m=mk2(theta=1.0,D=float(D)); fu=lambda f:(lambda w:w[3]-w[2])(m.bands_near_zero(m.frac_to_k(f),2)); ff=lambda f: m.gaps(m.frac_to_k(f))[0]
    flat=[m.refine(x,ff)[0] for x in flat]; ex,bmin=roots(m,fu,center)
    if ex: center=min(ex,key=lambda f:frac_dist(f,center))
    geo=[segment_geometry(flat[0],flat[1],f)[:2] for f in ex]
    rows.append(dict(D=D,flat=[f.tolist() for f in flat],upper=[f.tolist() for f in ex],geo=[list(map(float,g)) for g in geo],box_min=float(bmin)))
    print(f"D={D}: flat {tuple(np.round(flat[0],4))} {tuple(np.round(flat[1],4))} | upper roots {[tuple(np.round(f,4)) for f in ex]} | (t,off) {[(round(a,3),round(b,4)) for a,b in geo]} | box min {bmin:.2e}"); sys.stdout.flush()
json.dump(rows,open('rk_leg2_track_D.json','w'),indent=1)
