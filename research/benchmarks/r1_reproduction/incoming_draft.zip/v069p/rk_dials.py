"""Leg 1b probe (partner, ungated): at the closest strain-only approach, vary one physical dial at a time and watch the
in-segment offsets of tracked adjacent nodes. Base: eps=0.006, phi=30 (closest interior approach 0.071 in leg 1)."""
import numpy as np, sys, json, time
from rk_probe import mk
from bm_strain import BM, frac_dist, segment_geometry, s0
from braid import adjacent_nodes
import os
BASE=dict(eps=float(os.environ.get('RK_EPS','0.006')), phi=float(os.environ.get('RK_PHI','30')))
def mk2(eps=None, phi=None, theta=1.05, D=0.0, wscale=1.0):
    eps=BASE['eps'] if eps is None else eps; phi=BASE['phi'] if phi is None else phi
    return BM(N=4, theta_deg=theta, w1=110.0*wscale, ratio=0.8, eps=eps, phi_deg=phi, kinetic='lab_nn_full', geometry='exact', Dfield=D)
def state(m, flat_prev=None):
    fl=[f for v,f in m.find_nodes(ngrid=24,nkeep=10) if v<1e-6]; adj=adjacent_nodes(m,ngrid=24)
    if flat_prev is not None and len(fl)==2 and frac_dist(fl[0],flat_prev[0])>frac_dist(fl[1],flat_prev[0]): fl=[fl[1],fl[0]]
    geo=lambda q: segment_geometry(fl[0],fl[1],q)[:2]
    return fl,[geo(f) for _,f in adj['+']],[geo(f) for _,f in adj['-']],float(m.min_remote(ngrid=15,nkeep=3)[0])
if __name__=='__main__':
    dial=sys.argv[1]; vals=[float(x) for x in sys.argv[2].split(',')]; flat=None; rows=[]
    FIX={k:float(v) for k,v in (kv.split('=') for kv in os.environ.get('RK_FIX','').split(',') if kv)}   # e.g. RK_FIX='theta=1.0,D=20'
    for v in vals:
        t=time.time(); kw=dict(FIX); kw[dial]=v; m=mk2(**kw); fl,ug,lg,rem=state(m,flat)
        if len(fl)==2: flat=fl
        ins=[(lab,round(a,2),round(b,4)) for lab,g in (('U',ug),('L',lg)) for a,b in g if 0<a<1]
        close=min([abs(b) for lab,a,b in ins],default=None)
        rows.append(dict(dial=dial,value=v,flat=[f.tolist() for f in fl],upper_geo=ug,lower_geo=lg,min_remote=rem))
        print(f"{FIX} {dial}={v:g}: flat {len(fl)} remote {rem:.3f} | in-segment {ins} | closest interior {close} ({time.time()-t:.0f}s)"); sys.stdout.flush()
    json.dump(rows,open(f'rk_dial_{dial}_phi{int(BASE["phi"])}_eps{BASE["eps"]}.json','w'),indent=1)
