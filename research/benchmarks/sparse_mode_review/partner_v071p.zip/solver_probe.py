"""Measure dense subset eigh against sparse shift-invert for the real-basis Hamiltonian, N=6,8,10."""
import numpy as np, time, sys
from scipy.linalg import eigh
import scipy.sparse as sp, scipy.sparse.linalg as spl
from bm_strain import BM
from fast_engine import RealEngine
def T(fn, n=3):
    t = time.perf_counter()
    for _ in range(n): r = fn()
    return (time.perf_counter() - t) / n * 1e3, r
for N in (6, 8, 10):
    t0 = time.perf_counter(); m = BM(N=N, eps=0.007, phi_deg=15, theta_deg=1.0, kinetic='lab_nn_full', geometry='exact', Dfield=38.0)
    E = RealEngine(m); build = time.perf_counter() - t0; D = m.dim; f = np.array([0.72, 0.63])
    HR = E.HR(f); nnz = int(np.count_nonzero(HR)); S = sp.csr_matrix(HR)
    td, wd = T(lambda: eigh(HR, eigvals_only=True, subset_by_index=(D//2-3, D//2+2)), 2)
    lo = D//2 - 3
    def sparse_vals(sigma=0.0):
        return np.sort(spl.eigsh(S, k=6, sigma=sigma, which='LM', return_eigenvectors=False, tol=0, v0=np.ones(D)))
    try:
        ts, ws = T(lambda: sparse_vals(0.0), 2); err = float(np.abs(np.sort(ws) - wd).max())
    except Exception as e:
        ts, err, ws = float('nan'), float('nan'), None; print('  sparse failed:', repr(e)[:80])
    tb, _ = T(lambda: sp.csr_matrix(E.HR(f)), 2)
    print(f"N={N} D={D} build {build:.2f}s | density {nnz/D**2*100:.2f}% ({nnz//D} nnz/row) | dense subset {td:.1f} ms | sparse shift-invert(sigma=0) {ts:.1f} ms | max eigenvalue diff {err:.2e} meV | CSR assembly {tb:.1f} ms"); sys.stdout.flush()
