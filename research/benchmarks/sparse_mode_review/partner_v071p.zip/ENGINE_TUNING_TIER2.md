# Engine tuning, tier 2 — guarded sparse mode, and the R1 event located to N = 12

Partner, 22 September 2026. One core, single-thread BLAS. Physics unchanged; this is a declared engine mode with its own guards, tests and certification, not a silent swap. Nothing here is gated acceptance evidence.

## 1. Why a second tier

Tier 1 (the real-basis mode) removed the complex solve, but the remaining cost is still a **dense** subset solve: O(D³) work to extract six bands out of hundreds. The real-basis matrix has only ~6 nonzeros per row (1.9 % dense at N6, 0.7 % at N10), so the right tool is a sparse shift-invert solve.

| N | D | density | dense subset solve | sparse shift-invert | factor |
|---|---:|---:|---:|---:|---:|
| 6 | 348 | 1.87 % | 4.3 ms | 2.3 ms | 1.9× |
| 8 | 596 | 1.11 % | 14.9 ms | 3.6 ms | 4.1× |
| 10 | 932 | 0.72 % | 61.3 ms | 5.3 ms | **11.6×** |

The advantage grows with size, which is exactly where capability was missing. A Newton node solve at N10 falls from 249 ms to 22 ms, with the roots agreeing to 2×10⁻¹⁴.

## 2. The mode and its guards (`sparse_engine.SparseEngine`)

One CSR pattern is built once (static nonzeros ∪ the Dirac positions); per *k* only the Dirac entries are rewritten, so assembly is O(nnz) instead of O(D²). ARPACK shift-invert then returns the six bands nearest σ. Guards, all mandatory and all tested:

- **certification at construction** against the dense path at a probe state; the mode refuses to exist if the six-band window disagrees by more than 10⁻¹⁰ meV (observed: 3–9×10⁻¹³ meV at every cutoff from N6 to N12);
- **bracket check on every solve** — the returned window must straddle σ, so a window that slid off the target is rejected rather than relabelled;
- **band-range check** — bands requested outside the six-band window raise, instead of being taken from the edge;
- **deterministic start vector, tol = 0**, no iteration-count relaxation;
- `certify(f)` for re-checking against the dense path at any state along a run.

Five assertions cover it (`test_sparse_engine.py`), including that the sparse matrix equals the dense real matrix **exactly** (max difference 0.0) and that both refusals fire.

## 3. Capability gained: the R1 event across five cutoffs on one fixed basis

Same tracked node, same gates as the team's review requires (interior-t margin 0.02, root box 0.03, bracket walked with carried identities, Brent, one unchanged residual gate at 10⁻⁷, accumulated solve counts, periodic certification). Basis fixed by `index_set` to the union over the strain region, so every cutoff is one model throughout.

| N | fixed basis | D* (meV) | t | residual | evaluations / solves | runtime |
|---|---:|---:|---:|---:|---:|---:|
| 4 | 37 vectors | 38.829777 | 0.724 | 2.0e-12 | 11 / 264 | 0.2 s |
| 6 | 89 | 38.822629 | 0.724 | 2.0e-12 | 11 / 267 | 0.5 s |
| 8 | 149 | 38.822637 | 0.724 | 2.0e-12 | 11 / 267 | 0.9 s |
| 10 | 237 | **38.822637** | 0.724 | 2.0e-12 | 11 / 267 | 1.8 s |
| 12 | 335 | **38.822637** | 0.724 | 2.0e-12 | 11 / 267 | 3.8 s |

N6 → N8 moves the located event by 8×10⁻⁶ meV; **N8 → N10 → N12 does not move it at the printed precision**. The project has never before carried an event past N8, and the whole five-cutoff sequence costs 7 seconds on one core. Certification stayed ≤ 8.8×10⁻¹³ meV throughout.

This is cutoff stability of one located event on one fixed basis, not an infinite-cutoff bound and not a continuous-path result.

## 4. What this makes possible next

- **N8–N12 as routine**, not as a special batch: charge stations, fold diagnostics and short traces at those cutoffs are now minutes, not hours.
- **Atlas tracing at N8** rather than N4, so the surfaces are drawn where the cutoff error is already below the event spacing.
- **The continuous-path work the team asked for**: with a fixed index set (v070p) and per-state cost of ~20 ms at N10, dense station spacing along a leg becomes affordable, which is the practical prerequisite for root-identity tracking between stations.

## 5. Limits
Sparse mode is admissible only with its certification and window guards; ARPACK without them can silently return a shifted window. Timings are one-core; the parallel picture is unchanged. Sparse assembly and factorisation dominate at small D, so below N6 the dense path is as good or better. No accepted result is re-derived here, and every standing scope limit of the campaign still applies.

## 6. Files
`sparse_engine.py`, `test_sparse_engine.py`, `solver_probe.py` (the measurement above), `locate_event.py` + `locate_event_results.json` (the five-cutoff table), with the v070p fixed-basis engines and `fast_engine.py`.
