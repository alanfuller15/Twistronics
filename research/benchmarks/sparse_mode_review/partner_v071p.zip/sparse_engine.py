"""sparse_engine.py — guarded sparse shift-invert mode for the real-basis engine (partner v071p).

The real-basis Hamiltonian has ~6 nonzeros per row, and only six bands near charge neutrality are ever needed, so a
dense O(D^3) subset solve is wasteful. This mode keeps one CSR pattern (static nonzeros union the Dirac positions),
rewrites only the Dirac entries per k, and solves with ARPACK shift-invert. Guards, all required:
  * construction certifies the six-band window against the dense path at a probe state (<= cert_tol);
  * every solve checks that the returned window brackets the flat pair (an eigenvalue below and above it), so a window
    that slid off the target is rejected rather than relabelled;
  * deterministic start vector, tol=0 (machine precision), no iteration-count relaxation;
  * certify(f) re-checks against the dense path on demand; callers should re-certify periodically along a run.
Physics is unchanged: the matrix is the same one the dense path builds."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl
from scipy.linalg import eigh
from fast_engine import RealEngine
class WindowError(RuntimeError): pass
class SparseEngine(RealEngine):
    def __init__(self, m, tol=1e-9, cert_tol=1e-10, probe=(0.31, 0.27)):
        super().__init__(m, tol); D = self.D; HRs = self.HRs
        r0, c0 = np.nonzero(HRs); rows = [r0]; cols = [c0]
        for L in self.layers:
            i = L['idx']; rows += [i, i + 1, i, i + 1]; cols += [i, i + 1, i + 1, i]
        R = np.concatenate([np.asarray(x) for x in rows]); C = np.concatenate([np.asarray(x) for x in cols])
        S = sp.coo_matrix((np.zeros(len(R)), (R, C)), shape=(D, D)).tocsr(); S.sum_duplicates()
        rr = np.repeat(np.arange(D), np.diff(S.indptr)); S.data = HRs[rr, S.indices].copy()
        self.S = S; self.base = S.data.copy()
        def pos(r, c):
            s, e = S.indptr[r], S.indptr[r + 1]; j = s + int(np.searchsorted(S.indices[s:e], c))
            assert S.indices[j] == c; return j
        self.pmap = []
        for L in self.layers:
            i = L['idx']
            self.pmap.append(dict(aa=np.array([pos(x, x) for x in i]), bb=np.array([pos(x + 1, x + 1) for x in i]),
                                  ab=np.array([pos(x, x + 1) for x in i]), ba=np.array([pos(x + 1, x) for x in i]), L=L))
        self.v0 = np.ones(D); self.cert_tol = cert_tol; self.nS = 0
        self.certified = self.certify(np.array(probe))
        if self.certified > cert_tol: raise WindowError(f'sparse window disagrees with the dense path by {self.certified:.2e} meV at the probe state')
    def S_k(self, k):
        self.nS += 1; d = self.base.copy()
        for P in self.pmap:
            L = P['L']; pp = L['ppf'](k); a = L['hv'] * pp[:, 0]; b = L['hv'] * pp[:, 1]
            d[P['aa']] += a; d[P['bb']] -= a; d[P['ab']] -= b; d[P['ba']] -= b
        self.S.data = d; return self.S
    def window(self, f, sigma=0.0, nb=3):
        """six bands nearest sigma, with the bracket guard; returns (values, vectors) sorted"""
        w, v = spl.eigsh(self.S_k(self.kc(f)), k=2 * nb, sigma=sigma, which='LM', v0=self.v0, tol=0)
        o = np.argsort(w); w, v = w[o], v[:, o]
        if not (w[0] < sigma < w[-1]): raise WindowError(f'window [{w[0]:.3f},{w[-1]:.3f}] meV does not bracket sigma={sigma}')
        return w, v
    def bands(self, f, nb=3, sigma=0.0): return self.window(f, sigma, nb)[0]
    def frame_band(self, f, lo, n=2, sigma=0.0):
        """eigenvectors of absolute bands lo..lo+n-1 taken from the six-band window"""
        w, v = self.window(f, sigma); j = lo - (self.D // 2 - 3)
        if j < 0 or j + n > 6: raise WindowError('requested bands lie outside the six-band window')
        return w[j:j + n], v[:, j:j + n]
    def certify(self, f, sigma=0.0):
        """max |sparse - dense| over the six-band window at f (the dense path is the reference)"""
        D = self.D; wd = eigh(self.HR(f), eigvals_only=True, subset_by_index=(D // 2 - 3, D // 2 + 2))
        ws = self.bands(f, 3, sigma); return float(np.abs(np.sort(ws) - wd).max())
    def newton_node(self, f0, lo, maxit=40, tol=1e-11, trust=0.02, ext_min=1e-5, sigma=0.0):
        f = np.array(f0, float); hist = []
        for it in range(maxit):
            w, V = self.window(f, sigma); j = lo - (self.D // 2 - 3)
            if j < 1 or j + 2 > 5: raise WindowError('band pair too close to the window edge for the isolation check')
            wp = w[j:j + 2]; Fp = V[:, j:j + 2]; g = wp[1] - wp[0]; ext = min(wp[0] - w[j - 1], w[j + 2] - wp[1])
            hist.append(dict(it=it, gap=float(g), ext=float(ext)))
            if ext < ext_min: return f, g, dict(converged=False, reason='pair not isolated', evals=it + 1, hist=hist)
            if g < tol: return f, g, dict(converged=True, evals=it + 1, hist=hist)
            A = [self.dHR_proj(Fp, a) for a in (0, 1)]
            J = np.array([[(A[0][0, 0] - A[0][1, 1]) / 2, (A[1][0, 0] - A[1][1, 1]) / 2], [A[0][0, 1], A[1][0, 1]]])
            try: step = np.linalg.solve(J, -np.array([(wp[0] - wp[1]) / 2, 0.0]))
            except np.linalg.LinAlgError: return f, g, dict(converged=False, reason='singular Jacobian', evals=it + 1, hist=hist)
            n = np.linalg.norm(step); f = f + (step * trust / n if n > trust else step)
        return f, g, dict(converged=False, reason='maxit', evals=maxit, hist=hist)
