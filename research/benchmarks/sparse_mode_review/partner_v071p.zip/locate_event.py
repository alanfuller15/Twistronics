"""Locate the R1 crossing event at a declared cutoff and basis, sparse mode, with the review's gates.
Gates: interior-t margin, root box, bracket walked with carried identities, Brent (bracket-preserving),
one unchanged residual gate, accumulated solve counts, periodic re-certification against the dense path."""
import numpy as np, json, sys, time
from scipy.optimize import brentq
from bm_strain import BM, frac_dist, segment_geometry
from sparse_engine import SparseEngine
import atlas
T_MARGIN, BOX, TOL, RECERT = 0.02, 0.03, 1e-7, 8
def measure(x, seeds, N, index_set, acc):
    m = BM(N=N, theta_deg=x['theta'], w1=110.0 * x['P'], ratio=0.8, eps=x['eps'], phi_deg=x['phi'],
           kinetic='lab_nn_full', geometry='exact', Dfield=x['D'], index_set=index_set)
    E = SparseEngine(m); acc['certs'].append(E.certified); F = []
    for s in seeds['flat']:
        f, g, info = E.newton_node(np.array(s), E.D // 2 - 1)
        acc['solves'] += E.nS
        if not (info['converged'] and g < 1e-9): return None
        F.append(f)
    u, gu, iu = E.newton_node(np.array(seeds['node']), E.D // 2)
    acc['solves'] += E.nS
    if not (iu['converged'] and gu < 1e-9): return None
    if max(np.linalg.norm(np.array(a) - np.array(b)) for a, b in zip(F, seeds['flat'])) > BOX: return None
    t, off, L = segment_geometry(F[0], F[1], u)
    if not (T_MARGIN < t < 1 - T_MARGIN): return None
    return dict(flat=[f.tolist() for f in F], node=u.tolist(), t=float(t), offset=float(off), sep=float(L),
                seeds=dict(flat=[f.tolist() for f in F], node=u.tolist()))
def locate(x0, seeds, N, index_set, span=6.0):
    acc = dict(solves=0, certs=[], evals=0); last = {}
    def off(D):
        x = dict(x0); x['D'] = float(D); r = measure(x, last.get('seeds', seeds), N, index_set, acc)
        acc['evals'] += 1
        if r is None: raise RuntimeError('tracked root lost or a gate refused at D=%.4f' % D)
        last['r'] = r; last['seeds'] = r['seeds']; return r['offset']
    f0 = off(x0['D']); a = b = x0['D']; fa = fb = f0
    for step in np.arange(0.5, span, 0.5):
        for cand in (x0['D'] + step, x0['D'] - step):
            try: fc = off(cand)
            except RuntimeError: continue
            if f0 * fc < 0: a, b, fa, fb = (x0['D'], cand, f0, fc) if cand > x0['D'] else (cand, x0['D'], fc, f0); break
        else: continue
        break
    else: return dict(status='no sign change within the declared range', **acc)
    D = brentq(off, min(a, b), max(a, b), xtol=1e-9, rtol=1e-12, maxiter=100); r = last['r']
    return dict(status='ok' if abs(r['offset']) <= TOL else 'residual gate failed', D=float(D), residual=float(abs(r['offset'])),
                t=float(r['t']), pair_sep=float(r['sep']), N=N, basis_vectors=len(index_set), evals=acc['evals'],
                solves=acc['solves'], max_certification=float(max(acc['certs'])), flat=r['flat'], node=r['node'])
if __name__ == '__main__':
    seed = json.load(open('/home/claude/joint/seeds_legA.json'))[0]
    x = dict(seed['x']); x['eps'] = 0.0071; rows = []
    region = [dict(x, eps=e) for e in (0.0068, 0.0070, 0.0071, 0.0072, 0.0074, 0.0076, 0.0078)]
    for N in [int(a) for a in sys.argv[1:]] or [4]:
        idx = atlas.common_index_set(region, N, 'union'); t = time.perf_counter()
        r = locate(x, seed['seeds'], N, idx); r['seconds'] = time.perf_counter() - t; rows.append(r)
        print(("N={N} fixed basis {basis_vectors} vectors: " + ("D*={D:.6f} meV  t={t:.3f}  residual {residual:.1e}  | {evals} evaluations, {solves} sparse solves, certification <= {max_certification:.1e} meV, {seconds:.1f} s" if r['status'] == 'ok' else "{status}")).format(**r)); sys.stdout.flush()
    json.dump(rows, open('locate_event_results.json', 'w'), indent=1)
