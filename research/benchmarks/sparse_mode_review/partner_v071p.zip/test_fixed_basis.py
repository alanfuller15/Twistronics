"""Assertions for the fixed reciprocal-index basis (partner v070p)."""
import numpy as np, pytest
from bm_strain import BM
from tbg_ref import TBG
import atlas
EPS = (0.0068, 0.0070, 0.0072, 0.0076, 0.0078)
def states(): return [dict(eps=e, phi=15.0, theta=1.0, D=38.0, P=1.0) for e in EPS]
def test_native_basis_changes_with_strain_and_fixed_basis_does_not():
    nat = [len(atlas.native_index_set(x, 6)) for x in states()]
    assert len(set(nat)) > 1                                  # the documented jump exists
    U = atlas.common_index_set(states(), 6, 'union')
    dims = {atlas.build(x, 6, U).dim for x in states()}
    assert len(dims) == 1 and dims.pop() == 4 * len(U)
def test_fixed_basis_reproduces_the_native_model_when_the_sets_match():
    x = states()[0]; nat = atlas.native_index_set(x, 4)
    a = atlas.build(x, 4); b = atlas.build(x, 4, nat)
    k = a.frac_to_k(np.array([0.31, 0.27]))
    assert b.index_set_fixed and not a.index_set_fixed and a.dim == b.dim
    assert np.array_equal(a.H(k), b.H(k))
def test_both_engines_accept_the_same_index_set():
    x = states()[0]; U = atlas.common_index_set(states(), 4, 'union')
    a = BM(N=4, theta_deg=x['theta'], eps=x['eps'], phi_deg=x['phi'], kinetic='lab_nn_full', geometry='exact', Dfield=x['D'], index_set=U)
    b = TBG(N=4, theta=x['theta'], eps=x['eps'], phi=x['phi'], kinetic='lab_nn_full', Dfield=x['D'], index_set=U)
    assert a.dim == b.dim == 4 * len(U)
    assert np.abs(a.bands_near_zero(a.frac_to_k(np.array([0.31, 0.27])), 3) - b.bands(b.k(np.array([0.31, 0.27])), 3)).max() < 1e-9
def test_duplicate_indices_are_refused():
    with pytest.raises(ValueError): BM(N=4, eps=0.003, index_set=[(0, 0), (0, 0)])
