"""Assertions for the guarded sparse mode (partner v071p)."""
import numpy as np, pytest
from bm_strain import BM
from fast_engine import RealEngine
from sparse_engine import SparseEngine, WindowError
def model(N=6, **kw): return BM(N=N, eps=0.007, phi_deg=15, theta_deg=1.0, kinetic='lab_nn_full', geometry='exact', Dfield=38.0, **kw)
def test_sparse_window_matches_the_dense_path():
    m = model(); Es = SparseEngine(m); Ed = RealEngine(m)
    for f in (np.array([0.31, 0.27]), np.array([0.72, 0.63])):
        assert np.abs(np.sort(Es.bands(f, 3)) - Ed.bands(f, 3)).max() < 1e-10
    assert Es.certified < 1e-10
def test_sparse_and_dense_newton_agree():
    m = model(); Es = SparseEngine(m); Ed = RealEngine(m); seed = np.array([0.7704, 0.6288])
    fs, gs, i_s = Es.newton_node(seed, m.dim // 2); fd, gd, i_d = Ed.newton_node(seed, m.dim // 2)
    assert i_s['converged'] and i_d['converged'] and np.linalg.norm(fs - fd) < 1e-9 and gs < 1e-10
def test_window_that_does_not_bracket_sigma_is_refused():
    m = model(); E = SparseEngine(m)
    with pytest.raises(WindowError): E.bands(np.array([0.31, 0.27]), 3, sigma=-5000.0)
def test_bands_outside_the_window_are_refused():
    m = model(); E = SparseEngine(m)
    with pytest.raises(WindowError): E.frame_band(np.array([0.31, 0.27]), m.dim // 2 + 4)
def test_sparse_matrix_equals_the_dense_real_matrix():
    m = model(N=4); E = SparseEngine(m); k = m.frac_to_k(np.array([0.41, 0.19]))
    assert np.abs(E.S_k(k).toarray() - E.HR_k(k)).max() == 0.0
