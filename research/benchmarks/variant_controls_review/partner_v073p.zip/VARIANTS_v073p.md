# v073p — two engine variants completed: chiral-limit control and the K′ valley

Partner, 22 September 2026. One core, single-thread BLAS. Exploratory controls, not gated acceptance; they are offered as declared variants with their own tests. Neither changes any recorded campaign result.

## 1. Chiral-limit control (w₀ = 0) — the project's first external anchor

Reachable with existing parameters (`ratio=0.0`), so the contribution is a control plan plus its record, not new model code.

| check | result | independent reference |
|---|---|---|
| magic α from the bandwidth minimum (θ scan 1.04–1.12°, step 0.01°) | α = 0.5875, bandwidth 0.8544 meV; identical at N=6 and N=8 | analytic first magic α = 0.586 (Tarnopolsky–Kruchkov–Vishwanath) — agreement to 0.3 % |
| sublattice (chiral) symmetry of the spectrum | max \|E + reverse(E)\| = 1.2×10⁻¹¹ meV | exact in the chiral limit |
| flat-pair nodes | exactly (0,0) and (1/3,1/3) — K_M and K′_M | symmetry-protected Dirac points |
| Euler class of the flat pair (Wilson loop, N=6, θ=1.06°) | \|e₂\| = 1.000, closure +0.99, all plaquette dets +1 | fragile topology of the TBG flat bands, \|e₂\| = 1 (Song et al.; Ahn–Park–Yang) |
| node windings | +1, +1 → same charge, sum +2 = 2e₂ | Ahn–Park–Yang sum rule |

This is the first time a topological result of this project has been checked against a quantity computed outside it. It is a control, not a campaign: it does not validate any strained result, and 0.3 % agreement on α is a numerical bracket at a 0.01° scan step, not an accuracy claim.

## 2. K′ valley variant (`valley=±1`)

Implemented as the exact time-reversal partner, H_{K′}(k) = conj(H_K(−k)). Asserted bitwise: the K′ matrix equals the conjugated, momentum-reversed K matrix, and the spectra agree to 0.0 meV. C₂zT holds in the **same** σ_x basis in both valleys (residuals 5.7×10⁻¹⁴ and 5.5×10⁻¹⁴ meV), so every downstream tool — real-basis engine, sparse mode, node search, transport, windings — applies unchanged.

Mirror checks at the strained baseline: nodes mirror to 1.1×10⁻⁴ under k → −k; \|e₂\| = 1 in both valleys; endpoint per-band sign holonomies identical, flat₁ (−1, +1) and flat₂ (+1, +1).

**Two convention faults this variant exposed, both in my tooling, both now fixed or documented:**

1. **Periodic sewing is valley-dependent.** Wilson loops and sign holonomies re-embed the frame with an index shift; for K′ the identification runs the other way. With the K-valley shift, the K′ orientation closure came out +0.01 instead of ±1 and the endpoint holonomies collapsed to ≈ 0. With the shift sign tied to the valley, closure is +1.00 and the endpoint holonomies match K exactly. `topo.py` now derives the shift from `m.valley`, and a test asserts \|closure\| = 1 so this cannot pass silently again.
2. **A mirrored measurement must mirror every ingredient.** With mirrored node seeds and the mirrored periodic image but the *original* loop start offset, the braid-1 window at B = −0.30 read SAME in K′ against OPPOSITE in K. Mirroring the start offset as well gives OPPOSITE in both. The label is a convention artefact of an unmirrored start point, not a physical valley disagreement.

**Open, stated rather than patched:** the sign of the Wilson-loop Euler class is set by the arbitrary base-frame orientation (N=3 gives the same sign in both valleys, N=4 opposite), so `e₂(K′) = −e₂(K)` is **not** verified here. Only \|e₂\| = 1 is asserted. A signed inter-valley comparison needs a declared global orientation convention, which this variant does not supply.

## 3. Files
`bm_strain.py` (`valley` argument), `topo.py` (valley-aware sewing, shared measurements), `run_controls.py`, `test_valley_chiral.py` (5 assertions), `CHIRAL_CONTROL.json`, `VALLEY_MIRROR.json`.
