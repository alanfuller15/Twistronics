import numpy as np, json
from bm_strain import BM, sz, frac_dist
from knobs import add_harmonic
from gate import real_basis
from topo import euler_wilson, pair_charges, band_sign_holonomy
NAME = {1: 'K', -1: "K'"}
out = json.load(open('CHIRAL_CONTROL.json'))
print("chiral limit, N=6, theta=1.06 (alpha=0.5875):")
m = BM(N=6, theta_deg=1.06, ratio=0.0, eps=0.0, kinetic='none'); U = real_basis(m.nG)
e, cl, md = euler_wilson(m, U, nf1=18, nf2=30)
print("  Euler class of the chiral flat pair: e2 = %+.3f (closure %+.2f, min plaquette det %+.2f)   [literature |e2| = 1]" % (e, cl, md))
nodes = [f for v, f in m.find_nodes(ngrid=12, nkeep=6) if v < 1e-6]
print("  flat-pair nodes: %s" % [tuple(np.round(f, 4)) for f in nodes])
w1, w2, lab = pair_charges(m, U, nodes[:2])
print("  node windings %+.2f, %+.2f -> %s; sum %+d = 2 e2" % (w1, w2, lab, round(w1) + round(w2)))
out['chiral_euler'] = dict(N=6, theta=1.06, e2=float(e), closure=cl, min_det=md, w1=float(w1), w2=float(w2), label=lab, nodes=[f.tolist() for f in nodes])
json.dump(out, open('CHIRAL_CONTROL.json', 'w'), indent=1)
print("\nvalley mirror checks (N=4, lab_nn_full, exact geometry):")
V = {}
def mk(valley, B=None, **kw):
    m = BM(N=4, eps=0.003, phi_deg=0, kinetic='lab_nn_full', geometry='exact', valley=valley, **kw)
    if B: add_harmonic(m, B, mat=sz, use_sin=True)
    return m
for v in (1, -1):
    m = mk(v); U = real_basis(m.nG); e, cl, md = euler_wilson(m, U)
    V['e2_%d' % v] = float(e); print("  baseline Euler class, valley %s: e2 = %+.3f (closure %+.2f)" % (NAME[v], e, cl))
for B in (-0.25, -0.30):
    for v in (1, -1):
        m = mk(v, B=B, A_scalar=0.2); U = real_basis(m.nG)
        nd = [f for q, f in m.find_nodes(ngrid=15, nkeep=6) if q < 1e-6]
        if len(nd) != 2: print("  braid B=%.2f valley %s: %d nodes" % (B, NAME[v], len(nd))); continue
        w1, w2, lab = pair_charges(m, U, nd)
        V['braid_%s_%d' % (B, v)] = lab; print("  braid-1 window B=%+.2f, valley %s: windings %+.2f,%+.2f -> %s" % (B, NAME[v], w1, w2, lab))
for v in (1, -1):
    m = BM(N=4, eps=0.003, phi_deg=80, A_scalar=-0.30, ratio=0.88, kinetic='lab_nn_full', geometry='exact', valley=v)
    add_harmonic(m, -0.40, mat=sz, use_sin=True); add_harmonic(m, -1.8, mat=sz, use_sin=True, layer_sign=-1)
    U = real_basis(m.nG); D = m.dim
    h = {}
    for lab2, band in (('flat1', D // 2 - 1), ('flat2', D // 2)):
        for ax, a in (('k1', 0), ('k2', 1)): h['%s %s' % (lab2, ax)] = band_sign_holonomy(m, U, band, a, 0.0, n=80)
    V['endpoint_w1_%d' % v] = {k: round(x, 3) for k, x in h.items()}
    print("  endpoint sign holonomy, valley %s: %s" % (NAME[v], ", ".join("%s %+.2f" % (k, x) for k, x in h.items())))
json.dump(V, open('VALLEY_MIRROR.json', 'w'), indent=1)
