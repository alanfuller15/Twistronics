"""atlas.py — shared library for the joint mapping effort (partner). Model tag is explicit in every record:
kinetic='lab_nn_full', geometry='exact', constant tunnelling, cutoff N. Knobs: eps, phi, theta, D (meV), P (w scale).
Nothing here is gated: these are reconnaissance and tracing tools that produce candidates for the team's acceptance runs."""
import numpy as np, json, os
from bm_strain import BM, frac_dist, segment_geometry
from fast_engine import RealEngine
KNOBS = ('eps', 'phi', 'theta', 'D', 'P')
def build(x, N=4, index_set=None):
    return BM(N=N, index_set=index_set, theta_deg=x['theta'], w1=110.0 * x['P'], ratio=0.8, eps=x['eps'], phi_deg=x['phi'],
              kinetic='lab_nn_full', geometry='exact', Dfield=x['D'])
def engine(x, N=4, index_set=None): return RealEngine(build(x, N, index_set))
def lo_of(E, gap):   # 'flat' = bands (D/2-1, D/2); 'upper' = (D/2, D/2+1); 'lower' = (D/2-2, D/2-1)
    D = E.D; return {'flat': D // 2 - 1, 'upper': D // 2, 'lower': D // 2 - 2}[gap]
def nodes_from_grid(E, gap, n=24, keep=10, tol=1e-9):
    """grid seeds + Newton: the reconnaissance path (no carried identities)"""
    fn = E.gap({'lower': 1, 'flat': 2, 'upper': 3}[gap]); fs = np.linspace(0, 1, n, endpoint=False)
    V = np.array([[fn(np.array([a, b])) for b in fs] for a in fs]); lo = lo_of(E, gap); out = []
    seeds = sorted([(V[i, j], fs[i], fs[j]) for i in range(n) for j in range(n)
                    if V[i, j] <= min(V[(i + di) % n, (j + dj) % n] for di in (-1, 0, 1) for dj in (-1, 0, 1))])[:keep]
    for v, a, b in seeds:
        f, g, info = E.newton_node(np.array([a, b]), lo)
        if info['converged'] and g < tol and all(frac_dist(f % 1, q) > 0.01 for q in out): out.append(f % 1)
    return out
def survey(x, N=4, n=24):
    """one reconnaissance state: nodes in three gaps + segment geometry of adjacent nodes"""
    E = engine(x, N); rec = dict(x=dict(x), N=N, grid=n)
    for g in ('flat', 'upper', 'lower'): rec[g] = [f.tolist() for f in nodes_from_grid(E, g, n=n)]
    if len(rec['flat']) == 2:
        F = [np.array(f) for f in rec['flat']]
        for g in ('upper', 'lower'):
            rec[g + '_geo'] = [list(map(float, segment_geometry(F[0], F[1], np.array(q))[:2])) for q in rec[g]]
        inter = [(g, t, o) for g in ('upper', 'lower') for t, o in rec.get(g + '_geo', []) if 0 < t < 1]
        rec['closest_interior'] = min([abs(o) for _, _, o in inter], default=None)
    rec['solves'] = E.nH
    return rec
def native_index_set(x, N=4):
    return list(build(x, N).idx)
def common_index_set(states, N=4, mode='union'):
    """union (superset of every state's native basis) or intersection (subset of all) over a region"""
    sets = [set(map(tuple, native_index_set(x, N))) for x in states]
    out = set.union(*sets) if mode == 'union' else set.intersection(*sets)
    return sorted(out)
def measure(x, seeds, N=4, tol=1e-9, index_set=None):
    """carried-identity measurement: refine the tracked flat pair and the tracked adjacent node, return geometry.
    Returns None if any tracked root is lost — the caller must not silently continue."""
    E = engine(x, N, index_set); F = []
    for s in seeds['flat']:
        f, g, info = E.newton_node(np.array(s), lo_of(E, 'flat'))
        if not (info['converged'] and g < tol): return None
        F.append(f)
    if frac_dist(F[0], F[1]) < 1e-3: return None
    u, gu, iu = E.newton_node(np.array(seeds['node']), lo_of(E, seeds.get('gap', 'upper')))
    if not (iu['converged'] and gu < tol): return None
    t, off, L = segment_geometry(F[0], F[1], u)
    return dict(flat=[f.tolist() for f in F], node=u.tolist(), t=float(t), offset=float(off), sep=float(L), solves=E.nH,
                seeds=dict(flat=[f.tolist() for f in F], node=u.tolist(), gap=seeds.get('gap', 'upper')))
