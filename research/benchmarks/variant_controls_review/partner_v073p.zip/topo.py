"""Shared topology measurements for the valley and chiral controls (partner v073p)."""
import numpy as np
from scipy.linalg import eigh
from bm_strain import frac_dist
from gate import real_basis, classify
from euler import real_frame, shift_matrix
from braid import node_winding, transport
def euler_wilson(m, U, lo=None, nf1=24, nf2=40):
    """periodic sewing follows the valley: H_{K'}(k)=conj(H_K(-k)) identifies k+G with the OPPOSITE index shift"""
    D = m.dim; lo = D // 2 - 1 if lo is None else lo; v = getattr(m, 'valley', 1)
    S2 = shift_matrix(m, (0, -v)); S1 = shift_matrix(m, (-v, 0)); bp = b0 = None; ph = []; dets = []
    for f1 in np.linspace(0, 1, nf1, endpoint=False):
        fr = [real_frame(m, U, m.frac_to_k(np.array([f1, f2]))) for f2 in np.linspace(0, 1, nf2, endpoint=False)]
        b = fr[0]
        if bp is not None and np.linalg.det(bp.T @ b) < 0: b = b @ np.diag([1, -1]); fr[0] = b
        if b0 is None: b0 = b
        bp = b; W = np.eye(2)
        for j in range(nf2 - 1): W = W @ (fr[j].T @ fr[j + 1])
        W = W @ (fr[-1].T @ (S2 @ fr[0])); u, s, vt = np.linalg.svd(W); O = u @ vt
        dets.append(np.linalg.det(O)); ph.append(np.arctan2(O[1, 0], O[0, 0]))
    ext = np.unwrap(np.append(np.unwrap(ph), ph[0]))
    return (ext[-1] - ext[0]) / (2 * np.pi), float(np.linalg.det(bp.T @ (S1 @ b0))), float(min(dets))
def pair_charges(m, U, nodes, r=0.012):
    d = ((nodes[1] - nodes[0]) + 0.5) % 1 - 0.5; sa = nodes[0] + np.array([r, 0]); sb = nodes[0] + d + np.array([r, 0])
    base = real_frame(m, U, m.frac_to_k(sa))
    w1 = node_winding(m, U, nodes[0], r, 96, base)
    w2 = node_winding(m, U, nodes[0] + d, r, 96, transport(m, U, [sa, sb], base, nstep=300))
    return w1, w2, classify(w1, w2)
def band_sign_holonomy(m, U, band, axis, c, n=100):
    v = getattr(m, 'valley', 1); S = shift_matrix(m, (-v, 0)) if axis == 0 else shift_matrix(m, (0, -v)); prev = first = None
    for t in np.linspace(0, 1, n + 1):
        q = np.array([t, c]) if axis == 0 else np.array([c, t])
        HR = U.conj().T @ m.H(m.frac_to_k(q)) @ U; w, v = eigh(HR.real, subset_by_index=(band, band)); v = v[:, :1]
        if prev is not None and prev[:, 0] @ v[:, 0] < 0: v = -v
        if first is None: first = v
        prev = v
    return float(prev[:, 0] @ (S @ first)[:, 0])
