"""Assertions for the K' valley variant and the chiral-limit control (partner v073p)."""
import numpy as np, pytest
from bm_strain import BM, HBARV, frac_dist
from gate import real_basis
from topo import euler_wilson
def test_valley_is_the_exact_time_reversal_partner():
    kw = dict(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact')
    K, P = BM(valley=+1, **kw), BM(valley=-1, **kw); k = K.frac_to_k(np.array([0.31, 0.27]))
    assert np.array_equal(P.H(k), np.conj(K.H(-k)))
    assert np.abs(P.bands_near_zero(k, 3) - K.bands_near_zero(-k, 3)).max() == 0.0
def test_c2zt_holds_in_both_valleys_in_the_same_basis():
    for v in (+1, -1):
        m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact', valley=v); U = real_basis(m.nG)
        assert np.abs((U.conj().T @ m.H(m.frac_to_k(np.array([0.31, 0.27]))) @ U).imag).max() < 1e-9
def test_valley_rejects_bad_input():
    with pytest.raises(ValueError): BM(N=3, valley=0)
def test_euler_magnitude_is_one_in_both_valleys_and_the_sewing_closes():
    """|e2| = 1 in both valleys; the closure must be +-1, since a value near zero is the wrong sewing shift.
    The SIGN is not asserted: this estimator fixes the frame orientation by continuity from an arbitrary base
    frame, so the sign is run/convention dependent (recorded in v036 and reconfirmed here: N=3 gives the same
    sign in both valleys, N=4 opposite). A signed comparison needs a declared global orientation convention."""
    for v in (+1, -1):
        m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact', valley=v)
        e, cl, md = euler_wilson(m, real_basis(m.nG), nf1=12, nf2=20)
        assert abs(abs(cl) - 1) < 0.05, 'orientation closure must be +-1; near zero means the sewing shift is wrong'
        assert abs(abs(e) - 1) < 0.05 and md > 0
def test_chiral_limit_has_sublattice_symmetry_and_the_magic_alpha_brackets_the_analytic_value():
    m = BM(N=4, theta_deg=1.06, ratio=0.0, eps=0.0, kinetic='none')
    w = np.linalg.eigvalsh(m.H(m.frac_to_k(np.array([0.31, 0.27]))))
    assert np.abs(w + w[::-1]).max() < 1e-8
    assert abs(m.w1 / (HBARV * m.ktheta) - 0.586) < 0.01
