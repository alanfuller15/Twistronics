# Engine study — how the two engines work, where the time goes, and what can be tuned without changing physics

Partner study, 22 September 2026. Measurements on one core with single-thread BLAS (the team's execution policy), Python 3.12.3, NumPy 2.4.4, SciPy 1.17.1. Nothing here changes a model, a pin or a recorded result; the tuned paths are offered as a declared engine variant, with the complex path kept as reference and fallback.

## 1. The processes

| stage | what it does | code |
|---|---|---|
| model build | plane-wave basis \(|G|\le N|G_1|\) for both layers; static matrix: interlayer tunnelling \(T_j\), moiré harmonics, displacement field, mass | `BM.__init__/_build_static`, `TBG.__init__/_static` |
| per-k Hamiltonian | copy of the static matrix plus the Dirac 2×2 blocks \(\hbar v\,\mathbf{pp}\cdot\boldsymbol\sigma\) on the diagonal, \(\mathbf{pp}\) affine in \(k\) | `BM.H`, `TBG.H` |
| eigensolve | dense complex Hermitian solve for a few bands at charge neutrality | `bands_near_zero`, `TBG.bands` → `scipy.linalg.eigh(subset_by_index)` |
| search | grids of gap evaluations; Nelder–Mead refinement of nodes and gap minima | `find_nodes`, `refine`, `min_remote`, `gap_min` |
| topology | real frames in the \(C_{2z}T\) basis; parallel transport; windings; Wilson loops; holonomy | `gate.real_frame_checked`, `final_check.winding/transport2`, `euler.py`, `braid.py` |
| continuation (team harness) | tracked roots, fold solves, spatial comparisons, mesh/radius trials | team `measure.py`/`numerics.py` — **not audited here** |
| evidence | bound test records and publication gate | `test_evidence_bound.py` |

## 2. Where the time goes (per call, ms)

| engine | N | D | H(k) loop | H(k) vectorised | complex eigh, 6 values | complex → real transform (dense) | real eigh, 6 values |
|---|---:|---:|---:|---:|---:|---:|---:|
| BM | 4 | 196 | 0.57 | 0.10 | 2.8 | 1.7 | 1.2 |
| BM | 6 | 452 | 2.11 | 0.49 | 23.3 | 19.4 | 7.3 |
| BM | 8 | 796 | 4.22 | 1.98 | 126.4 | 96.5 | 34.2 |
| ref | 4 | 196 | 0.55 | 0.09 | 2.9 | 1.6 | 1.1 |
| ref | 6 | 452 | 1.42 | 0.35 | 24.5 | 17.5 | 6.8 |
| ref | 8 | 796 | 3.23 | 2.41 | 127.9 | 97.0 | 32.6 |

(`engine_stage_timings.json`; vectorised assembly is bitwise equal to the loop in all six cases.)

## 3. Findings

**F1. The complex eigensolve is essentially the whole bill.** Hamiltonian assembly is 3–20 % of a call at N4 and under 3 % at N8. Every search, frame and winding is a count of eigensolves.

**F2. The symmetry the campaign relies on makes a 4× cheaper solve available, and my toolkit was spending it.** In the \(C_{2z}T\) basis the Hamiltonian is real symmetric, and a real solve is 3.5–4× cheaper than the complex one. The frame code reached that basis by building the complex matrix and transforming it densely, an \(O(D^3)\) product that costs as much as the solve it replaces; the gap functions never used the real basis at all. The Dirac blocks are exactly real in that basis, \(\hbar v(pp_x\sigma_z-pp_y\sigma_x)\), so the real matrix can be built directly: transform the static part once, add \(O(D)\) real entries per \(k\).

**F3. Node refinement spends ~150 eigensolves per root.** Nelder–Mead on the gap: 146–165 evaluations per root in every case measured. The Hamiltonian is affine in \(k\), so the Jacobian of the pair's effective 2×2 d-vector in a fixed frame is exact and costs two small projections; Newton on it converges in 4–5 solves.

**F4.** The per-k assembly loop vectorises bitwise-identically (2–5×), but it is a small share of the total.

**F5.** Grids are embarrassingly parallel over \(k\) and deterministic under single-thread BLAS; process-level parallelism would scale near-linearly on multi-core hardware. Not measurable on this one-core machine; stated, not claimed.

## 4. The tuned mode (`fast_engine.RealEngine`)

Built from either engine instance after any `add_harmonic` call. At construction it transforms the static matrix to the real basis by the closed form of \(U^\dagger HU\) and **refuses** (raises `NotReal`) if the imaginary residual exceeds \(10^{-9}\) meV; the hBN mass model is refused (residual 2.00 meV). Per \(k\): one real copy plus \(O(D)\) Dirac entries, then a real solve. `newton_node(seed, lo)` refines a node of bands (lo, lo+1) and returns `converged=False` (caller falls back to Nelder–Mead) if the pair loses isolation, the Jacobian is singular, or 40 iterations pass; steps are trust-limited to 0.02.

## 5. Validation against the engines (`validate_fast_1/2`, `test_fast_engine.py`)

| check | result |
|---|---|
| real-mode matrix vs dense \((U^\dagger HU)\) real part, six models incl. braid window, R1 D=42, endpoint-type, both engines | ≤ \(4.5\times10^{-13}\) meV |
| eigenvalues vs complex engine, same models | ≤ \(5.7\times10^{-13}\) meV |
| Newton vs Nelder–Mead roots, 11 roots (baseline, braid B=−0.25/−0.30 at N4 and N6, R1 D=36 flat pair, R1 D=38 upper node) | agree to ≤ \(6\times10^{-12}\); Newton 4–5 solves, NM 146–165; Newton final gaps \(\le9\times10^{-12}\) meV vs NM \(\le3.3\times10^{-10}\) |
| charge labels, transported-frame estimator, four stations (braid SAME/OPPOSITE; R1 SAME/OPPOSITE) | windings identical to six decimals; labels identical |
| gap minimum on a gapped endpoint-type state, 18×18 grid + refinement | grid values ≤ \(7.5\times10^{-13}\) meV apart; refined minimum 4.329157532 meV in both |
| assertion tests (equivalence in five models, refusal of the mass model, Newton vs engine root, non-isolated refusal) | 8/8 pass |

## 6. Measured speedups

| operation | engine path | tuned path | factor |
|---|---|---|---|
| eigenvalues near zero, N8 | 139 ms | 33 ms | 4.2× |
| two-band real frame, N8 | 129 ms (+97 ms dense transform in my toolkit) | 30 ms | 4.3× (7.5× vs my toolkit) |
| node refinement, N4 | 0.26–0.53 s | 4–7 ms | 60–130× |
| node refinement, N6 | 3.95 s | 26–28 ms | ~150× |
| charge station, N4 (two 96-point loops + 300 transport steps) | 0.9–1.9 s | 0.34–0.60 s | ~3× |
| 18×18 gap grid, N4 | 2.49 s | 0.80 s | 3.1× |

Projected from per-call timings (not run end to end): a two-root refinement at N8 goes from ≈ 40 s to ≈ 0.3 s; an N8 charge station in my toolkit from ≈ 2 min to ≈ 15 s; a 24×24 N8 grid from ≈ 75 s to ≈ 19 s.

## 7. How a tuned engine should enter accepted runs

1. **Declare it**, like `kinetic` and `geometry`: e.g. `solver='real_c2zt'`, `refine='newton'`, recorded with every number it produces.
2. **Certify it** on the canonical checkpoints (baseline \(e_2\); both braids; first annihilation; endpoint \(w_1\); R1 candidate) against the complex path, with tolerances fixed before the run: roots ≤ \(10^{-9}\), gaps ≤ \(10^{-9}\) meV, windings ≤ \(10^{-6}\), labels identical.
3. **Keep the complex path** as reference and automatic fallback (`NotReal`; Newton non-convergence).
4. **Not bitwise.** Roots and frames agree to ~\(10^{-12}\), not bit for bit; bitwise resume checks must compare within one path.

## 8. Recommendations, ranked
1. Real mode for gap functions and frames: 3–4× on every eigensolve, guarded by construction.
2. Newton refinement with Nelder–Mead fallback: 60–150× on refinement, better final gaps.
3. Analytic derivatives for the fold diagnostics: \(H\) is affine in \(k\) and in every linear knob (field, harmonics, \(B_\tau\)); exact \(\partial H\) can replace finite differences in rank-one, curvature and slope checks.
4. Vectorised assembly (bitwise; small).
5. Process parallelism over grid points (deterministic; hardware-dependent).
6. For N ≥ 10, measure shift-invert Lanczos near zero energy before adopting anything.

## 9. Not covered
The team's harness code (continuation, fold solves, mesh/radius trials) was not read for this study; recommendations 1–3 apply wherever the same patterns occur there. Memory, iterative solvers and multi-core runs were not measured. No accepted result is changed or re-derived by this study.
