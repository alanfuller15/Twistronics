"""Stage-by-stage timing of the two engines (partner engine study). Single-thread BLAS. No physics changes."""
import time, numpy as np, json, sys
from scipy.linalg import eigh
import bm_strain as bs
from bm_strain import BM
from tbg_ref import TBG, R as Rref, HV, PX, PY
from gate import real_basis
u2 = np.array([[1, 1j], [1, -1j]]) / np.sqrt(2)
def T(fn, n):
    t = time.perf_counter()
    for _ in range(n): r = fn()
    return (time.perf_counter() - t) / n, r
def blockwise(H):
    n = H.shape[0] // 2; W = H.reshape(n, 2, n, 2)
    return np.einsum('ca,xcyd,db->xayb', u2.conj(), W, u2).reshape(2 * n, 2 * n)
def H_vec_bm(m, k):
    H = m.Hstat.copy(); nG = m.nG
    for lay in range(2):
        Rinv = bs.rot(-m.thetas[lay]); V = np.eye(2) + (1 - m.beta) * m.Es[lay]
        M = {'none': Rinv, 'full': V @ Rinv, 'lab_nn_full': Rinv @ V}[m.kinetic]
        p = k[None, :] + m.Gvec + (m.q[0][None, :] if lay == 1 else 0.0)
        pp = (p - m.Al[lay]) @ M.T; idx = 2 * nG * lay + 2 * np.arange(nG)
        H[idx, idx + 1] += bs.HBARV * (pp[:, 0] - 1j * pp[:, 1]); H[idx + 1, idx] += bs.HBARV * (pp[:, 0] + 1j * pp[:, 1])
    return H
def H_vec_ref(m, k):
    H = m.Hs.copy(); nG = m.nG
    for l in range(2):
        V = {'none': np.eye(2), 'geom_wrong': np.eye(2) - m.El[l], 'full': np.eye(2) + (1 - m.beta) * m.El[l], 'lab_nn_full': np.eye(2) + (1 - m.beta) * m.El[l]}[m.kinetic]
        M = Rref(-m.thl[l]) @ V if m.kinetic == 'lab_nn_full' else V @ Rref(-m.thl[l])
        pp = (m.origin + k[None, :] + m.Gv - m.Kl[l][0] - m.Al[l]) @ M.T; idx = 2 * nG * l + 2 * np.arange(nG)
        H[idx, idx + 1] += HV * (pp[:, 0] - 1j * pp[:, 1]); H[idx + 1, idx] += HV * (pp[:, 0] + 1j * pp[:, 1])
    return H
if __name__ == '__main__':
    out = []
    for N in (4, 6, 8):
        for name in ('bm', 'ref'):
            t0 = time.perf_counter()
            m = BM(N=N, eps=0.003, kinetic='lab_nn_full', geometry='exact') if name == 'bm' else TBG(N=N, eps=0.003, kinetic='lab_nn_full')
            build = time.perf_counter() - t0
            k = m.frac_to_k(np.array([0.31, 0.27])) if name == 'bm' else m.k(np.array([0.31, 0.27])); D = m.dim; lo = D // 2 - 1
            reps = {4: 20, 6: 6, 8: 2}[N]
            tH, H = T(lambda: m.H(k), reps)
            tHv, Hv = T(lambda: (H_vec_bm if name == 'bm' else H_vec_ref)(m, k), reps)
            t6, w6 = T(lambda: eigh(H, eigvals_only=True, subset_by_index=(D // 2 - 3, D // 2 + 2)), reps)
            tc2, (wc, vc) = T(lambda: eigh(H, subset_by_index=(lo, lo + 1)), reps)
            U = real_basis(m.nG) if name == 'bm' else m.real_basis()
            tdense, HRd = T(lambda: U.conj().T @ H @ U, max(1, reps // 2))
            tblock, HRb = T(lambda: blockwise(H), reps)
            tr2, (wr, vr) = T(lambda: eigh(HRb.real, subset_by_index=(lo, lo + 1)), reps)
            tr6, wr6 = T(lambda: eigh(HRb.real, eigvals_only=True, subset_by_index=(D // 2 - 3, D // 2 + 2)), reps)
            row = dict(engine=name, N=N, dim=D, build_s=build, H_loop_ms=1e3 * tH, H_vec_ms=1e3 * tHv, H_vec_equal=bool(np.array_equal(H, Hv)),
                       eigh_complex_6vals_ms=1e3 * t6, eigh_complex_2vecs_ms=1e3 * tc2, dense_realtransform_ms=1e3 * tdense, blockwise_realtransform_ms=1e3 * tblock,
                       block_vs_dense_maxdiff=float(np.abs(HRd - HRb).max()), imag_residual=float(np.abs(HRb.imag).max()),
                       eigh_real_2vecs_ms=1e3 * tr2, eigh_real_6vals_ms=1e3 * tr6, eig_real_vs_complex_maxdiff=float(np.abs(wr6 - w6).max()))
            out.append(row)
            print(f"{name} N={N} D={D}: build {build:.2f}s | H loop {row['H_loop_ms']:.2f} vec {row['H_vec_ms']:.2f} ms (equal {row['H_vec_equal']}) | eigh C 6vals {row['eigh_complex_6vals_ms']:.1f} C 2vecs {row['eigh_complex_2vecs_ms']:.1f} ms | real-basis transform dense {row['dense_realtransform_ms']:.1f} block {row['blockwise_realtransform_ms']:.2f} ms (diff {row['block_vs_dense_maxdiff']:.1e}, Im {row['imag_residual']:.1e}) | eigh R 2vecs {row['eigh_real_2vecs_ms']:.1f} R 6vals {row['eigh_real_6vals_ms']:.1f} ms (eig diff {row['eig_real_vs_complex_maxdiff']:.1e})"); sys.stdout.flush()
    json.dump(out, open('engine_stage_timings.json', 'w'), indent=1)
