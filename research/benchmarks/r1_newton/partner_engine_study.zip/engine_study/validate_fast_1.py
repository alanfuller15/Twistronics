import numpy as np, time
from bm_strain import BM, sz, s0
from tbg_ref import TBG
from knobs import add_harmonic
from gate import real_basis
from fast_engine import RealEngine, NotReal
rng = np.random.default_rng(7)
def models():
    a = BM(N=4, eps=0.003, kinetic='lab_nn_full', geometry='exact'); yield 'bm baseline N4', a
    b = BM(N=4, eps=0.003, A_scalar=0.2, kinetic='lab_nn_full', geometry='exact'); add_harmonic(b, -0.30, mat=sz, use_sin=True); yield 'bm braid-1 window N4', b
    c = BM(N=6, eps=0.007, phi_deg=15, theta_deg=1.0, kinetic='lab_nn_full', geometry='exact', Dfield=42.0); yield 'bm R1 D=42 N6', c
    d = BM(N=4, eps=0.003, phi_deg=80, A_scalar=-0.30, ratio=0.88, kinetic='lab_nn_full', geometry='exact'); add_harmonic(d, -0.40, mat=sz, use_sin=True); add_harmonic(d, -1.8, mat=sz, use_sin=True, layer_sign=-1); yield 'bm endpoint-type N4', d
    yield 'ref braid-1 window N4', TBG(N=4, eps=0.003, A=0.2, B=-0.30, kinetic='lab_nn_full')
    yield 'ref R1 D=42 N6', TBG(N=6, eps=0.007, phi=15, theta=1.0, kinetic='lab_nn_full', Dfield=42.0)
for name, m in models():
    E = RealEngine(m); U = real_basis(m.nG); dH = 0.0; dE = 0.0
    for _ in range(4):
        f = rng.random(2) * 2 - 0.5; k = E.kc(f); Hc = m.H(k)
        dH = max(dH, float(np.abs((U.conj().T @ Hc @ U).real - E.HR_k(k)).max()))
        wc = (m.bands_near_zero(k, 3) if E.kind == 'bm' else m.bands(k, 3)); dE = max(dE, float(np.abs(wc - E.bands(f, 3)).max()))
    print(f"{name}: static Im residual {E.static_residual:.1e} | max|HR_direct - (U^dag H U).real| {dH:.1e} meV | max eigenvalue diff {dE:.1e} meV")
m = BM(N=4, eps=0.003, kinetic='lab_nn_full', geometry='exact', mass=2.0)
try: RealEngine(m); print('mass model: NOT rejected (bad)')
except NotReal as e: print('mass model (C2zT-breaking): rejected ->', str(e)[:80])
