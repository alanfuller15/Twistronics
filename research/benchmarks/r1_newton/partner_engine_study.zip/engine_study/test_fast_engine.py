"""Assertion tests for fast_engine.py (partner engine study). A tuned path is admissible only if these pass."""
import numpy as np, pytest
from bm_strain import BM, sz, frac_dist
from tbg_ref import TBG
from knobs import add_harmonic
from gate import real_basis
from fast_engine import RealEngine, NotReal
def _bm(**kw):
    m = BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact', **{k: v for k, v in kw.items() if k != 'Bsin'})
    if 'Bsin' in kw: add_harmonic(m, kw['Bsin'], mat=sz, use_sin=True)
    return m
@pytest.mark.parametrize('m', [_bm(), _bm(A_scalar=0.2, Bsin=-0.3), _bm(Dfield=30.0), TBG(N=3, eps=0.003, A=0.2, B=-0.3, kinetic='lab_nn_full'), TBG(N=3, eps=0.007, phi=15, theta=1.0, kinetic='lab_nn_full', Dfield=40.0)])
def test_real_mode_equals_dense_transform_and_complex_spectrum(m):
    E = RealEngine(m); U = real_basis(m.nG); rng = np.random.default_rng(3)
    for _ in range(3):
        f = rng.random(2) * 2 - 0.5; k = E.kc(f)
        assert np.abs((U.conj().T @ m.H(k) @ U).real - E.HR_k(k)).max() < 1e-10
        wc = m.bands_near_zero(k, 3) if E.kind == 'bm' else m.bands(k, 3)
        assert np.abs(wc - E.bands(f, 3)).max() < 1e-10
def test_c2zt_breaking_model_is_refused():
    with pytest.raises(NotReal): RealEngine(BM(N=3, eps=0.003, kinetic='lab_nn_full', geometry='exact', mass=2.0))
def test_newton_root_matches_engine_refinement():
    m = _bm(); E = RealEngine(m); fn = lambda f: m.gaps(m.frac_to_k(np.asarray(f)))[0]
    for s in ((0.7694, 0.6166), (0.5916, 0.7366)):
        fN, gN = m.refine(np.array(s), fn); fW, gW, info = E.newton_node(np.array(s), m.dim // 2 - 1)
        assert info['converged'] and gW < 1e-10 and frac_dist(fN, fW) < 1e-9 and info['evals'] <= 10
def test_newton_refuses_non_isolated_pair():
    m = _bm(); E = RealEngine(m); f, g, info = E.newton_node(np.array([0.3, 0.3]), m.dim // 2 - 1, ext_min=1e6)
    assert not info['converged'] and info['reason'] == 'pair not isolated'
