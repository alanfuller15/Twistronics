import numpy as np, time, json, sys
from bm_strain import BM, sz, frac_dist
from tbg_ref import TBG
from knobs import add_harmonic
from gate import real_basis, classify
import final_check as fc
from fast_engine import RealEngine
out = {}
def bm_braid(B, N=4):
    m = BM(N=N, eps=0.003, A_scalar=0.2, kinetic='lab_nn_full', geometry='exact'); add_harmonic(m, B, mat=sz, use_sin=True); return m
def bm_r1(D, N=4): return BM(N=N, eps=0.007, phi_deg=15, theta_deg=1.0, kinetic='lab_nn_full', geometry='exact', Dfield=D)
cases = [('baseline N4', BM(N=4, eps=0.003, kinetic='lab_nn_full', geometry='exact'), [(0.7594, 0.6066), (0.5816, 0.7266)], 'flat'),
         ('braid B=-0.25 N4', bm_braid(-0.25), [(0.7459, 0.6123), (0.5172, 0.8278)], 'flat'),
         ('braid B=-0.30 N4', bm_braid(-0.30), [(0.7408, 0.6111), (0.5198, 0.8277)], 'flat'),
         ('R1 D=36 N4', bm_r1(36.0), [(0.4730, 0.7425), (0.8818, 0.5861)], 'flat'),
         ('R1 D=38 upper node A N4', bm_r1(38.0), [(0.7704, 0.6288)], 'upper'),
         ('braid B=-0.30 N6', bm_braid(-0.30, 6), [(0.7408, 0.6111), (0.5198, 0.8277)], 'flat')]
print("== node refinement: Nelder-Mead on the complex gap (engine) vs Newton on the real-basis d-vector (seeds offset by +0.01)")
rows = []
for name, m, seeds, which in cases:
    E = RealEngine(m); lo = m.dim // 2 - 1 if which == 'flat' else m.dim // 2
    gi = 0 if which == 'flat' else 1
    cnt = [0]
    def fn(f):
        cnt[0] += 1; w = m.bands_near_zero(m.frac_to_k(np.asarray(f)), 2); return (w[2] - w[1]) if which == 'flat' else (w[3] - w[2])
    for s in seeds:
        s0 = np.array(s) + 0.01
        cnt[0] = 0; t = time.perf_counter(); fN, gN = m.refine(s0, fn); tN = time.perf_counter() - t; nN = cnt[0]
        E.nH = 0; t = time.perf_counter(); fW, gW, info = E.newton_node(s0, lo); tW = time.perf_counter() - t
        d = frac_dist(fN, fW)
        rows.append(dict(case=name, seed=list(s), nm_root=fN.tolist(), nm_gap=float(gN), nm_evals=nN, nm_s=tN, newton_root=fW.tolist(), newton_gap=float(gW), newton_evals=info['evals'], newton_s=tW, converged=info['converged'], root_distance=float(d)))
        print(f"  {name} seed {s}: NM {tuple(np.round(fN, 6))} gap {gN:.1e} [{nN} evals, {tN:.2f}s] | Newton {tuple(np.round(fW, 6))} gap {gW:.1e} [{info['evals']} evals, {tW*1e3:.0f} ms, conv {info['converged']}] | |dx| {d:.1e}"); sys.stdout.flush()
out['refinement'] = rows
print("== charge labels with the transported-frame estimator: dense-transform frames vs real-engine frames (BM, N4)")
orig_frame = fc.frame; lab_rows = []
for name, m, seeds in [('braid B=-0.25', bm_braid(-0.25), [(0.7459, 0.6123), (0.5172, 0.8278)]), ('braid B=-0.30', bm_braid(-0.30), [(0.7408, 0.6111), (0.5198, 0.8277)]),
                       ('R1 D=36', bm_r1(36.0), [(0.4730, 0.7425), (0.8818, 0.5861)]), ('R1 D=42', bm_r1(42.0), [(0.4669, 0.7459), (0.8880, 0.5824)])]:
    E = RealEngine(m); U = real_basis(m.nG); lo = m.dim // 2 - 1
    p = [E.newton_node(np.array(s), lo)[0] for s in seeds]; d = ((p[1] - p[0]) + 0.5) % 1 - 0.5; r = 0.012
    sa = p[0] + np.array([r, 0]); sb = p[0] + d + np.array([r, 0]); res = {}
    for mode in ('dense', 'fast'):
        fc.frame = orig_frame if mode == 'dense' else (lambda m_, U_, k, lo_: E.frame_k(k, lo_))
        t = time.perf_counter(); base = fc.frame(m, U, m.frac_to_k(sa), lo)
        w1 = fc.winding(m, U, p[0], r, 96, base, lo); w2 = fc.winding(m, U, p[0] + d, r, 96, fc.transport2(m, U, [sa, sb], base, lo, n=300), lo)
        res[mode] = (w1, w2, classify(w1, w2), time.perf_counter() - t)
    fc.frame = orig_frame
    lab_rows.append(dict(state=name, dense=res['dense'][:3], fast=res['fast'][:3], dense_s=res['dense'][3], fast_s=res['fast'][3]))
    print(f"  {name}: dense w {res['dense'][0]:+.6f},{res['dense'][1]:+.6f} {res['dense'][2]} [{res['dense'][3]:.2f}s] | fast w {res['fast'][0]:+.6f},{res['fast'][1]:+.6f} {res['fast'][2]} [{res['fast'][3]:.2f}s]"); sys.stdout.flush()
out['labels'] = lab_rows
print("== gap minimum on a gapped state (endpoint-type, flat gap): same seeds, complex vs real gap function")
m = BM(N=4, eps=0.003, phi_deg=80, A_scalar=-0.30, ratio=0.88, kinetic='lab_nn_full', geometry='exact'); add_harmonic(m, -0.40, mat=sz, use_sin=True); add_harmonic(m, -1.8, mat=sz, use_sin=True, layer_sign=-1)
E = RealEngine(m); fc_c = lambda f: m.gaps(m.frac_to_k(np.asarray(f)))[0]; fc_r = E.gap(2)
fs = np.linspace(0, 1, 18, endpoint=False)
t = time.perf_counter(); Vc = np.array([[fc_c(np.array([a, b])) for b in fs] for a in fs]); tc = time.perf_counter() - t
t = time.perf_counter(); Vr = np.array([[fc_r(np.array([a, b])) for b in fs] for a in fs]); tr = time.perf_counter() - t
i, j = np.unravel_index(np.argmin(Vc), Vc.shape); s0 = np.array([fs[i], fs[j]])
gc = m.refine(s0, fc_c)[1]; gr = m.refine(s0, fc_r)[1]
print(f"  18x18 grid: complex {tc:.2f}s, real {tr:.2f}s, max grid diff {np.abs(Vc - Vr).max():.1e} meV | refined minimum complex {gc:.9f} real {gr:.9f} meV")
out['gap_minimum'] = dict(grid_complex_s=tc, grid_real_s=tr, grid_maxdiff=float(np.abs(Vc - Vr).max()), refined_complex=float(gc), refined_real=float(gr))
json.dump(out, open('validate_fast_2.json', 'w'), indent=1)
