# v077p — one consumer migrated to the guarded APIs

Partner, 22 September 2026. This closes **item 1 only** of `FABLE_HANDOFF.md`: one named consumer moved onto the
`variant-guard-repairs` APIs, bound to source and model identity. It does not migrate the others and does not close
any remaining boundary. Every number below is read from `MIGRATION_RESULTS.json`.

## What was migrated

| | |
|---|---|
| Consumer | `producers.valley_controls` braid-label measurement (v073p, v075p), previously calling `topo.pair_charges` |
| Migrated to | `guarded_topology.Sampler`, `Policy`, `geometry`, `mirror`, `pair_charges` |
| Source of engines | the preserved `partner_v074p.zip`, activated by `response_inputs.activate()`; local engine copies were removed so the model identity is unambiguous |
| Index set | 49 vectors, sha256 `9840ff7943dab1fe…`, frozen before model construction |
| Policy | the team's defaults, recorded verbatim in `MIGRATION_RESULTS.json` → `policy` |

**Not migrated, and not implied to be:** the chiral control, the endpoint sign holonomies, the Euler meshes, and every
atlas, sweep and tracer consumer. Sparse Newton and event detection remain unsupported per handoff item 2.

## Result — `MIGRATION_RESULTS.json`

All eight measurements returned `PASSED_SAMPLED_GATES`; no refusals.

| B | valley +1 | valley −1 |
|---|---|---|
| −0.25 | SAME | SAME |
| −0.30 | OPPOSITE | OPPOSITE |

Each row covers radii 0.012 and 0.008 with loop/transport intervals 96/300 and 192/600. K′ geometry is the exact
coordinate inversion of K (`guarded_topology.mirror`), coordinate policy `unwrapped`, and the transport endpoints are
the loop start points, which `pair_charges` refuses if they disagree. Largest evaluated node gap 1.53e-10 meV against
the policy threshold 1e-06; smallest |winding| 0.998975; 16472 ledger rows; wall time [historical: run-local timing, not a bound record] over 24.6 s.

This reproduces the labels my own producer reported in v075p, now through an API whose loop, transport and mirroring
are the team's rather than mine. It is a sampled measurement under the stated policy, not a geometric proof that the
mirrored comparison is the same measurement.

## Controls re-run here
`test_guards.py`: 38 passed (`TESTS_LOCAL.log`). `record_controls.py` regenerated `NEGATIVE_CONTROLS.json`, including
the retired 2×2 LU counterexample. My own pre-delivery checks also ran: `metamorphic.py` (see `METAMORPHIC.log`) and
`claim_lint.py` against this README (`LINT.log`).

## Scope
One consumer, one model family, N=4, sampled gates (see `MIGRATION_RESULTS.json` and `LINT.log`). Nothing here establishes a continuous path, a complete inventory,
an Euler-class change, physical validity, or the migration of any other consumer.

## Reproduce
```
python migrated_valley_control.py        # writes MIGRATION_RESULTS.json
python -m pytest -q -p no:cacheprovider test_guards.py
python record_controls.py && python metamorphic.py && python claim_lint.py .
```
