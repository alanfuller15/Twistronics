"""metamorphic.py — declared metamorphic relations for the engines (partner self-check).

No ground truth exists for these outputs, so each relation states an invariant connecting two runs, with its
precondition and tolerance declared before execution. A violation is a defect in the code or in the relation; both
must be reported, neither may be tuned away."""
import numpy as np, json, sys
import response_inputs; response_inputs.activate()   # engines come from the preserved partner archive
import bm_strain as bs
from bm_strain import BM
from gate import real_basis
from fast_engine import RealEngine
R = []
def rec(name, statement, ok, detail, **values):
    """values are stored as NUMERIC leaves, not only inside the formatted detail string, so a record reader (and the
    claim linter) can bind prose numbers to them"""
    R.append(dict(relation=name, statement=statement, holds=bool(ok), detail=detail, values=values))
    print(f"  {'PASS' if ok else 'FAIL'}  {name}: {detail}")
KW = dict(N=4, eps=0.004, theta_deg=1.05, kinetic='lab_nn_full', geometry='exact')
f0 = np.array([0.31, 0.27])
# MR1: the heterostrain tensor is invariant under phi -> phi + 180, so the Hamiltonian must be bitwise identical
a, b = BM(phi_deg=17.0, **KW), BM(phi_deg=197.0, **KW)
d = float(np.abs(a.H(a.frac_to_k(f0)) - b.H(b.frac_to_k(f0))).max())
rec('MR1 strain-angle period 180', 'H(phi) == H(phi+180) bitwise', d == 0.0, f'max |dH| = {d:.3e} meV', max_dH_meV=d)
# MR2: C3 of the moire lattice, phi -> phi + 60. PRECONDITION (added after this relation failed as first written):
# both models must use ONE common index set. Without it the two angles retain different bases (47 vs 71 vectors at
# N=4) and the comparison is between different finite models, not a test of the symmetry.
m1u, m2u = BM(phi_deg=17.0, **KW), BM(phi_deg=77.0, **KW)
common = sorted(set(m1u.idx) | set(m2u.idx))
m1, m2 = BM(phi_deg=17.0, index_set=common, **KW), BM(phi_deg=77.0, index_set=common, **KW)
bw = abs(m1.flat_bandwidth(10) - m2.flat_bandwidth(10)); rg = abs(m1.min_remote(ngrid=12, nkeep=3)[0] - m2.min_remote(ngrid=12, nkeep=3)[0])
bwu = abs(m1u.flat_bandwidth(10) - m2u.flat_bandwidth(10)); rgu = abs(m1u.min_remote(ngrid=12, nkeep=3)[0] - m2u.min_remote(ngrid=12, nkeep=3)[0])
rec('MR2 C3 strain direction (common basis)', 'bandwidth and min remote gap invariant under phi -> phi+60 on one common index set',
    bw < 1e-5 and rg < 1e-3, f'common basis ({len(common)} vectors): |d bandwidth| = {bw:.2e} meV, |d remote gap| = {rg:.2e} meV; '
    f'native per-angle bases ({len(m1u.idx)} vs {len(m2u.idx)} vectors): {bwu:.2e} and {rgu:.2e} meV',
    common_vectors=len(common), d_bandwidth_meV=bw, d_remote_gap_meV=rg, native_a=len(m1u.idx), native_b=len(m2u.idx),
    native_d_bandwidth_meV=bwu, native_d_remote_gap_meV=rgu)
# MR3: the index set is a basis, so permuting its order must not change any eigenvalue
base = BM(phi_deg=17.0, **KW); idx = list(base.idx)
rng = np.random.default_rng(11); perm = [idx[i] for i in rng.permutation(len(idx))]
p = BM(phi_deg=17.0, index_set=perm, **KW)
w1 = base.bands_near_zero(base.frac_to_k(f0), 3); w2 = p.bands_near_zero(p.frac_to_k(f0), 3)
dd = float(np.abs(w1 - w2).max())
rec('MR3 basis-order invariance', 'permuting index_set leaves the spectrum unchanged', dd < 1e-9, f'max |dE| = {dd:.3e} meV over six central bands', max_dE_meV=dd)
# MR4: the Hamiltonian is homogeneous of degree 1 in (hbar v, w0, w1): scaling all three by L scales every
# eigenvalue by L and leaves node positions fixed
L = 2.5; hv0 = bs.HBARV
try:
    bs.HBARV = hv0 * L; s = BM(phi_deg=17.0, w1=110.0 * L, **KW)
    ws = s.bands_near_zero(s.frac_to_k(f0), 3)
finally:
    bs.HBARV = hv0
w0 = base.bands_near_zero(base.frac_to_k(f0), 3)
scale_err = float(np.abs(ws - L * w0).max() / max(abs(L * w0).max(), 1e-30))
rec('MR4 homogeneity in (hbar v, w)', 'scaling hbar v and w by L scales every eigenvalue by L', scale_err < 1e-12, f'max relative deviation = {scale_err:.3e}', max_relative_deviation=scale_err, factor=L)
# MR5: valley mirror, exact time reversal
K, P = BM(phi_deg=17.0, valley=+1, **KW), BM(phi_deg=17.0, valley=-1, **KW)
k = K.frac_to_k(f0); dv = float(np.abs(P.H(k) - np.conj(K.H(-k))).max())
de = float(np.abs(P.bands_near_zero(k, 3) - K.bands_near_zero(-k, 3)).max())
rec('MR5 valley time reversal', "H_K'(k) == conj(H_K(-k)); spectra mirror", dv == 0.0 and de == 0.0, f'max |dH| = {dv:.1e}, max |dE| = {de:.1e} meV', max_dH_meV=dv, max_dE_meV=de)
# MR6: reciprocal periodicity is only approximate in a truncated basis; report the size rather than asserting equality
w_a = base.bands_near_zero(base.frac_to_k(f0), 3); w_b = base.bands_near_zero(base.frac_to_k(f0 + np.array([1.0, 0.0])), 3)
rec('MR6 reciprocal periodicity (diagnostic)', 'E(f) vs E(f+G): truncation-limited, reported not asserted', True, f'max |dE| = {float(np.abs(w_a - w_b).max()):.3e} meV at N=4 (this is the finite-basis edge effect, not a bug)', max_dE_meV=float(np.abs(w_a - w_b).max()), N=4)
# MR7: the real-basis engine must agree with the native path under every relation above
for tag, m in (('K', K), ("K'", P), ('permuted basis', p)):
    E = RealEngine(m); U = real_basis(m.nG)
    dE = float(np.abs(E.bands(f0, 3) - m.bands_near_zero(m.frac_to_k(f0), 3)).max())
    rec(f'MR7 fast==native [{tag}]', 'real-basis engine reproduces the native spectrum', dE < 1e-9, f'max |dE| = {dE:.2e} meV', max_dE_meV=dE)
json.dump(R, open('METAMORPHIC.json', 'w'), indent=1)
print(f"\n{sum(1 for r in R if not r['holds'])} violation(s) of {len(R)} declared relations")
