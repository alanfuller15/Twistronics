"""migrated_valley_control.py — guarded entry point for the braid-label portion of the valley control (v078p).

This is a NEW entry point. The preserved `producers.py` is unchanged and still calls the historical topology APIs;
running it does not invoke this module.

Delivery contract (v077p review items 1-4): the eight expected cases are declared in PLAN_MIGRATION.json before the
run and matched against actual rows; every row is persisted to ROWS.jsonl as it completes, so a later failure cannot
lose earlier work; discovery and refinement exceptions are recorded as structured stages and the cases they block are
enumerated; the process exits nonzero unless every expected case is ACCEPTED, and `run_status` distinguishes an
incomplete run from a complete one; evidence is serialized rather than counted (constructor defaults and active
constants in MODELS.json, harmonic arguments, ordered indices in BASIS.json, complete geometry arrays in
GEOMETRY.json, policy, module hashes, and every raw Sampler diagnostic in DIAGNOSTICS.jsonl), with each row bound to
those records by identifier.

Grid: two COUPLED settings, (radius 0.012, loop 96, transport 300) and (radius 0.008, loop 192, transport 600); not an
independent radius-by-mesh product."""
import numpy as np, json, hashlib, sys, time, os, traceback
import guarded_topology as gt          # activates and path-inserts the preserved partner_v074p archive
from bm_strain import BM, sz, HBARV    # therefore resolved from that archive, not from local copies
from knobs import add_harmonic
from gate import real_basis
PLAN_PATH = 'PLAN_MIGRATION.json'
SRC = ['guarded_topology.py', 'guarded_sparse.py', 'migrated_valley_control.py', 'response_inputs.py', 'partner_v074p.zip', PLAN_PATH]
MODEL_DEFAULTS = dict(N=4, eps=0.003, phi_deg=0.0, theta_deg=1.05, A_scalar=0.2, ratio=0.8, w1=110.0, nu=0.16, beta=3.14,
                      kinetic='lab_nn_full', geometry='exact', cutoff_tol=1e-6, mass=0.0, Dfield=0.0, w_kappa=0.0, w_mode='average')
HARMONIC = dict(mat='sz', use_sin=True, layer_sign=1)
def sha(path): return hashlib.sha256(open(path, 'rb').read()).hexdigest()
def case_id(B, valley, radius): return f'B{B:+.2f}_v{valley:+d}_r{radius:.3f}'
def build(valley, B, indices):
    m = BM(valley=valley, index_set=indices, **MODEL_DEFAULTS)
    add_harmonic(m, B, mat=sz, use_sin=HARMONIC['use_sin'], layer_sign=HARMONIC['layer_sign']); return m
class Run:
    def __init__(self, out_dir):
        self.dir = out_dir; os.makedirs(out_dir, exist_ok=True)
        self.rows_path = os.path.join(out_dir, 'ROWS.jsonl'); open(self.rows_path, 'w').close()
        self.diag_path = os.path.join(out_dir, 'DIAGNOSTICS.jsonl'); open(self.diag_path, 'w').close()
        self.models = {}; self.geoms = {}; self.stages = []
    def row(self, rec):
        with open(self.rows_path, 'a') as f: f.write(json.dumps(rec) + '\n'); f.flush(); os.fsync(f.fileno())
    def diagnostics(self, case, rows):
        start = sum(1 for _ in open(self.diag_path))
        with open(self.diag_path, 'a') as f:
            for r in rows: f.write(json.dumps(dict(case=case, **r)) + '\n')
            f.flush(); os.fsync(f.fileno())
        return dict(file='DIAGNOSTICS.jsonl', first_line=start, count=len(rows))
    def stage_failure(self, stage, exc, blocked):
        rec = dict(stage=stage, exception=type(exc).__name__, message=str(exc)[:400],
                   traceback=traceback.format_exc()[-800:], blocked_cases=blocked); self.stages.append(rec); return rec
def main(out_dir='RUN', discovery=None, measure=None):
    """`discovery` and `measure` are injection points used only by the declared failure controls."""
    plan = json.load(open(PLAN_PATH)); expected = [c['case_id'] for c in plan['expected_cases']]
    run = Run(out_dir); pol = gt.Policy()
    policy = {k: float(getattr(pol, k)) for k in ('reality_meV', 'hermiticity_meV', 'external_gap_meV', 'internal_gap_meV',
              'root_gap_meV', 'overlap_min', 'sewing_loss_max', 'phase_step_max_rad', 'unit_winding_tol')}
    frozen = list(BM(**MODEL_DEFAULTS).idx)
    json.dump(dict(vectors=len(frozen), sha256=hashlib.sha256(json.dumps([list(t) for t in frozen]).encode()).hexdigest(),
                   ordered_indices=[list(t) for t in frozen]), open(os.path.join(out_dir, 'BASIS.json'), 'w'), indent=1)
    seen = set()
    for B in plan['B_values']:
        try:
            mK = build(+1, B, frozen)
            run.models[f'discovery_B{B:+.2f}'] = dict(valley=+1, B=B, defaults=MODEL_DEFAULTS, harmonic=dict(HARMONIC, amplitude=B),
                active_constants=dict(HBARV_meV_angstrom=float(HBARV)), dim=int(mK.dim), basis='BASIS.json')
            ns = plan['node_search']
            finder = discovery or (lambda m: [f for q, f in m.find_nodes(ngrid=ns['ngrid'], nkeep=ns['nkeep']) if q < ns['accept_gap_meV']])
            nodes = finder(mK)
        except Exception as exc:
            blocked = [c for c in expected if c.startswith(f'B{B:+.2f}')]
            rec = run.stage_failure(f'discovery:B{B:+.2f}', exc, blocked)
            for c in blocked: run.row(dict(case_id=c, status='BLOCKED', blocked_by=rec['stage'])); seen.add(c)
            print(f"  discovery failed at B={B:+.2f}: {type(exc).__name__}; {len(blocked)} case(s) BLOCKED"); sys.stdout.flush(); continue
        if len(nodes) != 2:
            blocked = [c for c in expected if c.startswith(f'B{B:+.2f}')]
            run.stages.append(dict(stage=f'discovery:B{B:+.2f}', exception='NoPair', message=f'{len(nodes)} exact nodes found, 2 required', blocked_cases=blocked))
            for c in blocked: run.row(dict(case_id=c, status='NO_PAIR', nodes_found=len(nodes))); seen.add(c)
            print(f"  no pair at B={B:+.2f} ({len(nodes)} nodes); {len(blocked)} case(s) NO_PAIR"); sys.stdout.flush(); continue
        for radius, intervals, tint in plan['coupled_settings']:
            gid = f'geom_B{B:+.2f}_r{radius:.3f}'
            g = gt.geometry(np.array(nodes), radius, intervals, tint); gm = gt.mirror(g)
            run.geoms[gid] = dict(K=g, Kprime=gm, coupled_setting=dict(radius=radius, loop_intervals=intervals, transport_intervals=tint))
            for valley, geom in ((+1, g), (-1, gm)):
                cid = case_id(B, valley, radius); seen.add(cid)
                m = build(valley, B, frozen); led = []
                run.models[f'model_{cid}'] = dict(valley=valley, B=B, defaults=MODEL_DEFAULTS, harmonic=dict(HARMONIC, amplitude=B),
                    active_constants=dict(HBARV_meV_angstrom=float(HBARV)), dim=int(m.dim), basis='BASIS.json')
                S = gt.Sampler(m, policy=pol, U=real_basis(m.nG), ledger=led, name=cid); t0 = time.perf_counter()
                try:
                    r = (measure or gt.pair_charges)(S, geom)
                    rec = dict(case_id=cid, status='ACCEPTED', label=r['label'], windings=r['windings'],
                               node_gaps_meV=r['node_gaps_meV'], lo=r['lo'], gate_status=r['status'])
                except gt.Rejected as exc:
                    rec = dict(case_id=cid, status='REJECTED', rejection=str(exc), rejection_type=type(exc).__name__)
                except Exception as exc:
                    rec = dict(case_id=cid, status='ERROR', exception=type(exc).__name__, message=str(exc)[:300])
                rec.update(B=B, valley=valley, radius=radius, loop_intervals=intervals, transport_intervals=tint,
                           model_ref=f'model_{cid}', geometry_ref=gid, geometry_side='K' if valley > 0 else 'Kprime',
                           policy=policy, diagnostics=run.diagnostics(cid, led), seconds_measurement_only=time.perf_counter() - t0)
                run.row(rec); print(f"  {cid}: {rec['status']} {rec.get('label') or rec.get('rejection', '')}"); sys.stdout.flush()
    rows = [json.loads(l) for l in open(run.rows_path)]
    accepted = [r for r in rows if r['status'] == 'ACCEPTED']; missing = [c for c in expected if c not in seen]
    complete = len(accepted) == len(expected) and not missing and not run.stages
    summary = dict(run_status='COMPLETE' if complete else 'INCOMPLETE', expected_cases=expected,
                   accepted=[r['case_id'] for r in accepted], rejected=[r['case_id'] for r in rows if r['status'] == 'REJECTED'],
                   blocked=[r['case_id'] for r in rows if r['status'] in ('BLOCKED', 'NO_PAIR')],
                   errored=[r['case_id'] for r in rows if r['status'] == 'ERROR'], missing_cases=missing,
                   stage_failures=run.stages, plan=PLAN_PATH, plan_sha256=sha(PLAN_PATH),
                   source_sha256={p: sha(p) for p in SRC}, policy=policy, rows_file='ROWS.jsonl',
                   diagnostics_file='DIAGNOSTICS.jsonl', basis_file='BASIS.json', models_file='MODELS.json', geometry_file='GEOMETRY.json')
    json.dump(run.models, open(os.path.join(out_dir, 'MODELS.json'), 'w'), indent=1)
    json.dump(run.geoms, open(os.path.join(out_dir, 'GEOMETRY.json'), 'w'), indent=1)
    json.dump(summary, open(os.path.join(out_dir, 'SUMMARY.json'), 'w'), indent=1)
    json.dump({f: sha(os.path.join(out_dir, f)) for f in sorted(os.listdir(out_dir)) if f != 'MANIFEST.json'},
              open(os.path.join(out_dir, 'MANIFEST.json'), 'w'), indent=1)
    print(f"\nrun_status={summary['run_status']} accepted={len(accepted)}/{len(expected)} rejected={len(summary['rejected'])} "
          f"blocked={len(summary['blocked'])} missing={len(missing)} stages={len(run.stages)}")
    return 0 if complete else 1
if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else 'RUN'))
