# v078p — the one-consumer migration contract finished

Partner, 22 September 2026. Same model, same guarded modules, same eight cases as v077p. This pass finishes the
consumer's **delivery behaviour** (v077p review items 1–5); it adds no physics claim and no numerical expansion.
Every number below is read from the records named beside it.

This is a **new guarded entry point for the braid-label portion of the valley control**. The preserved `producers.py`
is unchanged and still invokes the historical topology APIs; running it does not invoke this module.

## Item responses

| # | Required change | Implemented | Control evidence |
|---|---|---|---|
| 1 | nonzero exit when an expected case is rejected or a pair is missing; eight case ids declared in advance | `PLAN_MIGRATION.json` declares the case ids; `SUMMARY.json` accounts for accepted/rejected/blocked/errored/missing; exit 0 only when all eight are ACCEPTED | all-rejected control: exit 1, 8 REJECTED rows retained; no-pair control: exit 1, 8 NO_PAIR rows; positive run exit 0 (`FAILURE_CONTROLS.json`, `EXIT_CODES.json`) |
| 2 | persist rows incrementally; keep structured discovery failures; distinguish incomplete from complete | rows are appended and fsynced to `ROWS.jsonl` as they complete; discovery exceptions are recorded as stages with their blocked case list | discovery-fails-after-first-B: exit 1, run_status INCOMPLETE, 4 earlier rows kept and 4 blocked, output JSON written |
| 3 | serialize the promised evidence; a verifier must reconstruct, and removing or mismatching a file must fail | `MODELS.json` (constructor defaults, active constants, harmonic arguments), `BASIS.json` (ordered indices + hash), `GEOMETRY.json` (complete arrays), `DIAGNOSTICS.jsonl` (16472 raw rows), `MANIFEST.json`; each row cites its model, geometry and diagnostics slice | `verify_migration.py`: 77/77 checks pass on the intact run; missing `GEOMETRY.json` → exit 1; a single altered angle increment → exit 1 (`VERIFY_RUN.json`, `EXIT_CODES.json`) |
| 4 | migration-specific frozen plan and source diff; record node discovery and the coupled settings as performed | `PLAN_MIGRATION.json` declares `node_search.performed = true` with its parameters, the two coupled settings, the exit policy and the case list; `SOURCE.diff` is the consumer diff against the v077p version | plan hash bound in `SUMMARY.json`; the verifier checks the expected list against the plan |
| 5 | failed metamorphic assertions must affect the exit code; diagnostic rows need a separate status | asserted rows carry `status: ASSERTED`; MR6 is `DIAGNOSTIC_ONLY` with `holds: null`; the runner exits 1 on any failed assertion | forced MR1 violation: MR1 `holds` = False, exit 1; clean run exit 0 |

## Measurement

All values in this section are read from `SUMMARY.json` and `ROWS.jsonl` in `RUN/`.

run_status **COMPLETE**, 8/8 accepted, no rejections, no blocked cases.

| B | radius / loop / transport | valley +1 | valley −1 |
|---|---|---|---|
| −0.25 | 0.012 / 96 / 300 | SAME | SAME |
| −0.25 | 0.008 / 192 / 600 | SAME | SAME |
| −0.30 | 0.012 / 96 / 300 | OPPOSITE | OPPOSITE |
| −0.30 | 0.008 / 192 / 600 | OPPOSITE | OPPOSITE |

Two **coupled** settings, not an independent radius-by-mesh product. Largest evaluated node gap 1.52593e-10 meV against
the policy threshold 1e-06 meV; smallest |winding| 0.998975. Winding signs depend on frame orientation, so only the
SAME/OPPOSITE product is reported. K′ geometry is the exact coordinate negation of K, checked by the verifier.

## Suites
`test_guards.py` and `test_claim_lint.py`: 42 passed together [historical: pytest console output, not a bound record]. The linter was fixed with regression fixtures
(`lint_fixtures/`, `test_claim_lint.py`) for unicode minus and correctly-rounded binding, not by relaxing a rule; a
stale third digit is still caught.

## Scope
One consumer, one model family, N=4, sampled gates, as declared in `PLAN_MIGRATION.json`. Not an independent model, a continuous braid proof, a complete
inventory, a cutoff study or physical validation. Other consumers, sparse Newton and event detection are untouched.

## Reproduce
```
python migrated_valley_control.py RUN && python verify_migration.py RUN
python failure_controls.py && python -m pytest -q -p no:cacheprovider test_guards.py test_claim_lint.py
```
