"""verify_migration.py — independent verifier for a run directory (v077p review item 3).

From the retained records alone it: checks the manifest against the files, rebuilds each row's node gaps and winding
sum from the raw diagnostics, checks every recorded frame coordinate against the complete geometry, checks the exact
K/K-prime coordinate negation, checks every case against the frozen plan, and confirms the exit contract. Removing or
mismatching a required evidence file fails verification."""
import json, hashlib, os, sys, numpy as np
REQUIRED = ['SUMMARY.json', 'ROWS.jsonl', 'DIAGNOSTICS.jsonl', 'MODELS.json', 'GEOMETRY.json', 'BASIS.json', 'MANIFEST.json']
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def verify(d, plan_path='PLAN_MIGRATION.json'):
    checks = []
    def ck(name, ok, detail=''): checks.append(dict(check=name, ok=bool(ok), detail=detail)); return ok
    for f in REQUIRED:
        if not ck(f'required file {f}', os.path.exists(os.path.join(d, f))): return checks
    man = json.load(open(os.path.join(d, 'MANIFEST.json')))
    for f, h in man.items():
        ck(f'manifest hash {f}', os.path.exists(os.path.join(d, f)) and sha(os.path.join(d, f)) == h)
    S = json.load(open(os.path.join(d, 'SUMMARY.json'))); plan = json.load(open(plan_path))
    rows = [json.loads(l) for l in open(os.path.join(d, 'ROWS.jsonl'))]
    diags = [json.loads(l) for l in open(os.path.join(d, 'DIAGNOSTICS.jsonl'))]
    geom = json.load(open(os.path.join(d, 'GEOMETRY.json'))); models = json.load(open(os.path.join(d, 'MODELS.json')))
    ck('plan hash', S['plan_sha256'] == sha(plan_path))
    ck('expected case list matches the plan', S['expected_cases'] == [c['case_id'] for c in plan['expected_cases']])
    ck('every row has a declared case id', all(r['case_id'] in S['expected_cases'] for r in rows))
    ck('exit contract', (S['run_status'] == 'COMPLETE') == (len(S['accepted']) == len(S['expected_cases']) and not S['stage_failures']))
    for r in rows:
        if r['status'] != 'ACCEPTED':
            ck(f"{r['case_id']} non-accepted row carries a reason", bool(r.get('rejection') or r.get('blocked_by') or r.get('nodes_found') is not None or r.get('exception')))
            continue
        ck(f"{r['case_id']} model record", r['model_ref'] in models and models[r['model_ref']]['valley'] == r['valley'])
        g = geom[r['geometry_ref']][r['geometry_side']]
        sel = diags[r['diagnostics']['first_line']:r['diagnostics']['first_line'] + r['diagnostics']['count']]
        ck(f"{r['case_id']} diagnostics slice", len(sel) == r['diagnostics']['count'] and all(x['case'] == r['case_id'] for x in sel))
        # node gaps rebuilt from the retained spectra
        gaps = [float(x['energies_meV'][x['lo'] - x['first_band'] + 1] - x['energies_meV'][x['lo'] - x['first_band']])
                for x in sel if x['kind'] == 'frame' and x['where'].startswith('node:')]
        ck(f"{r['case_id']} node gaps rebuilt", len(gaps) == 2 and max(abs(a - b) for a, b in zip(sorted(gaps), sorted(r['node_gaps_meV']))) < 1e-18,
           f'rebuilt {gaps} vs recorded {r["node_gaps_meV"]}')
        # winding sums rebuilt from the retained angle increments
        for i, w in enumerate(r['windings']):
            steps = [x['step_rad'] for x in sel if x['kind'] == 'angle' and x['where'] == f'loop:{i}']
            ck(f"{r['case_id']} winding {i} rebuilt", abs(sum(steps) / np.pi - w) < 1e-12, f'{sum(steps)/np.pi} vs {w}')
        # every recorded frame coordinate must belong to the declared geometry
        pts = {tuple(np.round(p, 12)) for p in (g['loops'][0] + g['loops'][1] + g['transport'] + g['nodes'])}
        bad = [x['f'] for x in sel if x['kind'] == 'frame' and tuple(np.round(x['f'], 12)) not in pts]
        ck(f"{r['case_id']} frame coordinates within the declared geometry", not bad, f'{len(bad)} stray coordinate(s)')
    # exact K/K-prime negation of every coordinate
    for gid, g in geom.items():
        for key in ('nodes', 'loops', 'transport'):
            a = np.asarray(g['K'][key]); b = np.asarray(g['Kprime'][key])
            ck(f'{gid} {key} exact negation', np.array_equal(a, -b))
    return checks
if __name__ == '__main__':
    d = sys.argv[1] if len(sys.argv) > 1 else 'RUN'
    ch = verify(d); bad = [c for c in ch if not c['ok']]
    json.dump(dict(directory=d, checks=ch, failed=len(bad), passed=len(ch) - len(bad)), open(f'VERIFY_{os.path.basename(d)}.json', 'w'), indent=1)
    for c in bad[:8]: print('  FAIL', c['check'], c['detail'][:90])
    print(f"{len(ch) - len(bad)}/{len(ch)} checks passed in {d}")
    sys.exit(1 if bad else 0)
