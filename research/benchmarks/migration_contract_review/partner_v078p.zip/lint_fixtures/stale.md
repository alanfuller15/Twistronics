Largest node gap 1.61e-10 meV from `REC.json`.
The difference is 0.000179 meV per `REC.json`.
