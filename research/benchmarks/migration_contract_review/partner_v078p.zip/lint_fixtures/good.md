Largest node gap 1.53e-10 meV and overlap 0.997858 from `REC.json`.
The difference is 0.000173 meV per `REC.json`.
A minus sign in prose: −0.30 knob value from `REC.json`.
