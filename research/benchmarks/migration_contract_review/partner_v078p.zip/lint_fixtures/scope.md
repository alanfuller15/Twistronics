Every measurement passed and all contracts are closed.
