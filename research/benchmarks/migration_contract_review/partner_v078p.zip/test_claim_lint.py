"""Regression fixtures for claim_lint (v077p review: fix the linter with fixtures, not by weakening it)."""
import claim_lint as cl
def flags(doc): return cl.lint('lint_fixtures', [f'lint_fixtures/{doc}'])
def test_correctly_rounded_values_bind():
    assert [f for f in flags('good.md') if f['rule'] == 'R2-number'] == []
def test_unicode_minus_is_parsed_and_binds():
    # the record holds knob_B = -0.30; prose writes it with a unicode minus, which must parse and bind
    assert [f for f in flags('good.md') if f['rule'] == 'R2-number'] == []
def test_stale_digits_are_caught():
    bad = [f['value'] for f in flags('stale.md') if f['rule'] == 'R2-number']
    assert '1.61e-10' in bad and '0.000179' in bad
def test_scope_word_without_evidence_is_flagged():
    assert any(f['rule'] == 'R1-scope' for f in flags('scope.md'))
