"""claim_lint.py — pre-delivery linter for my own deliverables.

Two rules, both mechanical:
  R1 SCOPE: a sentence asserting coverage (every/all/none/never/always/unchanged/proved/closes/complete/fully)
     must carry an evidence pointer in the same line (a .json/.log/.xml/.py path, a test name, or a sha).
  R2 NUMBER: every numeral in prose must resolve to a value in the record THAT LINE CITES (not merely somewhere in
     the package - matching against the whole package still passes drift, which is how the first version of this
     linter missed two of the three values the reviewer found).
  R3 UNBOUND: a line carrying a measured numeral must cite a record at all.
Notation: unicode scientific notation (6.93x10^-13 written with superscripts) is parsed, and a citation stays in
scope for the lines that follow it until the next citation or heading, so a table cites its record once. A value
quoted from an earlier package is accepted only when tagged [historical: ...] on the same line.
Exit code 1 if any violation, so a package build can refuse to ship."""
import json, re, sys, glob, os
SCOPE = r'\b(every|all|none|never|always|unchanged|proved|proven|closes|closed|complete|completely|fully|exhaustive|guaranteed|no\s+\w+\s+(?:changed|remains))\b'
EVID = r'(\.json|\.log|\.xml|\.jsonl|\.py\b|sha256|test_|`[A-Za-z_][A-Za-z0-9_.]*`)'
NUM = r'(?<![\w.])(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)(?![\w.])'
MINUS = {'−': '-', '–': '-'}          # unicode minus / en dash used in prose
SUP = {'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁻':'-','⁺':'+'}
SCI = re.compile(r'(-?\d+(?:\.\d+)?)\s*[x×]\s*10([⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+)')
HIST = re.compile(r'\[historical:')
def normalise(line):
    for k, v in MINUS.items(): line = line.replace(k, v)
    """rewrite unicode scientific notation as plain floats so numerals can be compared with record values"""
    def sub(m):
        exp = ''.join(SUP.get(c, c) for c in m.group(2))
        try: return repr(float(m.group(1)) * 10 ** int(exp))
        except ValueError: return m.group(0)
    return SCI.sub(sub, line)
SKIP_WORDS = ('20260', '2026', '2025', '19', '20')          # dates and years
def record_values(pkg, only=None):
    vals = []
    files = [os.path.join(pkg, o) for o in only] if only else glob.glob(os.path.join(pkg, '**', '*.json'), recursive=True)
    for p in files:
        if not os.path.exists(p): continue
        try: d = json.load(open(p))
        except Exception: continue
        def walk(o):
            if isinstance(o, dict):
                for v in o.values(): walk(v)
            elif isinstance(o, list):
                for v in o: walk(v)
            elif isinstance(o, (int, float)) and not isinstance(o, bool): vals.append(float(o))
        walk(d)
    return vals
def sigfigs(tok):
    t = tok.lstrip('-').split('e')[0].split('E')[0]
    digits = t.replace('.', '').lstrip('0')
    return max(1, len(digits.rstrip('0')) if '.' in t else len(digits))
def rounds_to(v, tok):
    """a prose numeral binds if it is the correctly rounded form of the record value at the digits written"""
    try: return float(f'%.{sigfigs(tok)}g' % v) == float(tok)
    except (ValueError, TypeError, OverflowError): return False
def bound(x, vals, rel=2e-3, tok=None):
    for v in vals:
        if x == v: return True
        if tok is not None and rounds_to(v, tok): return True
        if v != 0 and abs(x - v) <= rel * abs(v): return True
        if abs(x) < 1e-12 and abs(v) < 1e-12: return True
    return False
CITE = re.compile(r'([A-Za-z0-9_\-]+\.json)')
MEASURED = re.compile(r'(meV|singular|overlap|gap|closure|residual|winding|bandwidth|alpha|α|e₂|e2)\b', re.I)
def lint(pkg, docs=None, rel=2e-3):
    allvals = record_values(pkg); out = []
    docs = docs or glob.glob(os.path.join(pkg, '*.md'))
    for doc in docs:
        scope = []                                   # citation stays in scope until the next citation or heading
        for i, line in enumerate(open(doc), 1):
            s = normalise(line.strip())
            if s.startswith('#'): scope = []
            if not s or s.startswith('|---') or s.startswith('```'): continue
            if re.search(SCOPE, s, re.I) and not re.search(EVID, s):
                out.append(dict(rule='R1-scope', doc=os.path.basename(doc), line=i, text=s[:150]))
            cited = CITE.findall(s) or scope
            if CITE.findall(s): scope = CITE.findall(s)
            if HIST.search(s): continue
            vals = record_values(pkg, cited) if cited else allvals
            nums = [m.group(1) for m in re.finditer(NUM, s)]
            nums = [t for t in nums if not t.startswith(SKIP_WORDS) and len(t.replace('-', '').replace('.', '')) > 2]
            if nums and MEASURED.search(s) and not cited:
                out.append(dict(rule='R3-unbound', doc=os.path.basename(doc), line=i, value=','.join(nums[:4]), text=s[:150]))
            for tok in nums:
                x = float(tok)
                if not bound(x, vals, rel, tok):
                    out.append(dict(rule='R2-number', doc=os.path.basename(doc), line=i, value=tok, text=s[:150]))
    return out
if __name__ == '__main__':
    pkg = sys.argv[1]; v = lint(pkg, sys.argv[2:] or None)
    for r in v: print(f"  {r['rule']:11s} {r['doc']}:{r['line']}  {r.get('value','')}  {r['text'][:110]}")
    print(f"{len(v)} violation(s) in {pkg}")
    sys.exit(1 if v else 0)
