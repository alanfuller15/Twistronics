"""failure_controls.py — the three consumer release controls the v077p review requires, plus the metamorphic gate
control. Declared runtime substitutions on unchanged source, in disposable output directories. Their fake node and
measurement results are NOT scientific evidence."""
import json, subprocess, sys, os, hashlib, numpy as np
import migrated_valley_control as mv
import guarded_topology as gt
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
def files(d): return {f: sha(os.path.join(d, f)) for f in sorted(os.listdir(d))} if os.path.isdir(d) else {}
R = []
def control(name, out_dir, **kw):
    code = mv.main(out_dir, **kw)
    s = json.load(open(os.path.join(out_dir, 'SUMMARY.json'))) if os.path.exists(os.path.join(out_dir, 'SUMMARY.json')) else None
    rows = [json.loads(l) for l in open(os.path.join(out_dir, 'ROWS.jsonl'))] if os.path.exists(os.path.join(out_dir, 'ROWS.jsonl')) else []
    rec = dict(control=name, exit_code=code, run_status=(s or {}).get('run_status'), rows=len(rows),
               statuses={k: len((s or {}).get(k, [])) for k in ('accepted', 'rejected', 'blocked', 'errored', 'missing_cases')},
               stage_failures=[st['stage'] for st in (s or {}).get('stage_failures', [])], produced=files(out_dir))
    R.append(rec); print(f"  {name}: exit={code} run_status={rec['run_status']} rows={len(rows)} statuses={rec['statuses']}"); sys.stdout.flush()
    return rec
def reject_all(S, g): raise gt.Rejected('injected_rejection', control='all_rejected')
def no_pair(m): return []
class DiscoveryFails:
    """succeeds for the first B, raises for the second"""
    def __init__(self): self.n = 0
    def __call__(self, m):
        self.n += 1
        if self.n > 1: raise RuntimeError('injected discovery failure after the first B')
        return [f for q, f in m.find_nodes(ngrid=15, nkeep=6) if q < 1e-6]
if __name__ == '__main__':
    control('all_measurements_rejected', 'CONTROL_REJECTED', measure=reject_all)
    control('no_pair_found', 'CONTROL_NO_PAIR', discovery=no_pair)
    control('discovery_fails_after_first_B', 'CONTROL_DISCOVERY', discovery=DiscoveryFails())
    # metamorphic gate: a forced MR1 violation must produce a false assertion AND a nonzero exit
    env = dict(os.environ, FORCE_MR1_FAILURE='1', OPENBLAS_NUM_THREADS='1')
    p = subprocess.run([sys.executable, 'metamorphic.py'], capture_output=True, text=True, env=env)
    m = json.load(open('METAMORPHIC.json'))
    forced = [r for r in m if r['relation'].startswith('MR1')]
    R.append(dict(control='forced_MR1_violation', exit_code=p.returncode, mr1_holds=forced[0]['holds'] if forced else None,
                  diagnostic_rows=[r['relation'] for r in m if r.get('status') == 'DIAGNOSTIC_ONLY']))
    print(f"  forced_MR1_violation: exit={p.returncode} MR1 holds={forced[0]['holds'] if forced else None}")
    p2 = subprocess.run([sys.executable, 'metamorphic.py'], capture_output=True, text=True, env=dict(os.environ, OPENBLAS_NUM_THREADS='1'))
    R.append(dict(control='metamorphic_clean', exit_code=p2.returncode))
    print(f"  metamorphic_clean: exit={p2.returncode}")
    json.dump(dict(note='synthetic contract controls; fake node/measurement results are not scientific evidence', controls=R),
              open('FAILURE_CONTROLS.json', 'w'), indent=1)
