# Joint mapping plan — your compute, targeted tracing, one atlas

Partner proposal, 22 September 2026. Exploratory tooling, N=4 unless stated; `kinetic='lab_nn_full'`, exact geometry, constant tunnelling. Nothing here is gated; everything produces candidates for the team's frozen-plan acceptance runs.

## The split

| you (time and cores) | me (per batch) | team (Codex) |
|---|---|---|
| run `sweep.py` over declared grids, unattended; resumable, append-only, one BLAS thread per worker | triage the sweep output, seed and run `trace.py`, produce the event-surface atlas, validate and package | freeze plans, run the gated two-engine N4/N6 acceptance on the candidates the atlas ranks |

Reconnaissance is embarrassingly parallel and deterministic; tracing is sequential per curve but cheap. Neither blocks the other: you can be sweeping the next region while I trace the last one.

## Measured costs (this one-core box)

- reconnaissance state (three 24×24 gap grids + Newton refinement): **1.8 s**; ≈2,000 states/hour/worker, scaling linearly in workers.
- traced curve point (carried identities, secant on the event condition): **7–9 eigensolves, ~0.1 s** — about 20× cheaper than one reconnaissance state.
- demo traces, both from one seed: the crossing surface along strain direction, \(D^\*(\phi=15^\circ)=38.0846\) meV → \(37.2088\) (16°) → \(38.0733\) (17°), lost at 18°; and along strain magnitude, \(D^\*(\epsilon)=38.08\) (0.70 %) → \(39.59\) (0.72 %) → \(41.18\) (0.74 %) → \(42.83\) (0.76 %). Four curve points in 0.3 s.

So a surface in two free knobs sampled 200×200 is ≈4×10⁴ points ≈ **1 core-hour**, not the 22 I estimated in the audit from grid-priced states. The audit's volume-scan figures stand: 9×10⁷ states, 5.7 core-years.

## What the demo already taught us (both findings are in the tooling, not the physics)

1. **The 24-grid reconnaissance misses narrow-cone nodes.** The sweep's seed list for the R1 state did not contain the node that actually crosses; its cone is narrow at some fields, so the grid minimum never flags it. The tracer, given that seed list, correctly refused to report an event. Remedy in the plan: seeds come from **both** sweeps and recorded tracked runs, and `survey()` gains a dense local box around the flat-pair segment before a region is declared clean.
2. **A bracket must be walked, not jumped.** Evaluating the event condition at centre ± span loses the tracked root; stepping outward while carrying identities finds the sign change. Both guards are now in `trace.py`, and a lost root ends the curve with a message rather than a silent extrapolation.

## Run order

1. **Calibrate** (you, 10 min): `python sweep.py plan_calib.json calib.jsonl <workers>` on ~50 states; it prints s/state and states/hour for your machine.
2. **Region sweeps** (you, unattended): one plan per region, e.g. ε ∈ [0.5, 0.8] %, φ ∈ [0, 60°), θ ∈ {0.97, 1.00, 1.05}, D ∈ [−50, 50] meV at 5 meV, P = 1. Resume is automatic; kill and restart freely.
3. **Seeds** (either): `python sweep.py seeds out.jsonl seeds.json 0.05`.
4. **Traces** (me): one curve per seed and free knob; output is a point list with model tag, the tracked roots, and the pair separation at each point.
5. **Atlas** (me): surfaces assembled per event type (crossing, isolation boundary, fold loci), each point carrying its tracked identities so the team can re-seed an accepted run anywhere on it.
6. **Acceptance** (team): gated N4/N6, two engines, on the ranked candidates.

## Wording of the deliverable
An **atlas of located event surfaces within declared bounds at a stated resolution**, with the tracked identities that produced each point. Not a full map: sampling still proves nothing between samples, and a narrow-cone node can hide from any grid. If one leg needs an exhaustive statement, that remains the certified-continuation branch.

## Files
`atlas.py` (shared state/measurement library), `sweep.py` (parallel, resumable reconnaissance + seed extraction), `trace.py` (continuation with carried identities and walked brackets), demo outputs `sweep_demo.jsonl`, `seeds_demo.json`, `seeds_legA.json`, `trace_phi_A.json`, `trace_eps_A.json`, engines and `fast_engine.py` from the unified tree.
