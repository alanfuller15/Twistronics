"""sweep.py — parallel reconnaissance over a declared grid. Deterministic (each state is an independent eigenproblem;
one BLAS thread per worker), append-only JSONL with resume, and a seed file for the tracer.
Usage:  python sweep.py plan.json out.jsonl [workers]        # resumes automatically if out.jsonl exists
plan.json: {"N":4,"grid":24,"axes":{"eps":[...],"phi":[...],"theta":[...],"D":[...],"P":[...]}}"""
import json, sys, os, time, itertools, hashlib
def states(plan):
    ax = plan['axes']; keys = [k for k in ('eps', 'phi', 'theta', 'D', 'P')]
    for combo in itertools.product(*[ax[k] for k in keys]):
        x = dict(zip(keys, map(float, combo))); yield hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest()[:16], x
def work(item):
    key, x, N, n = item
    import atlas, time as _t
    t = _t.perf_counter()
    try: rec = atlas.survey(x, N=N, n=n); rec['status'] = 'ok'
    except Exception as e: rec = dict(x=x, N=N, status='error', error=repr(e)[:200])
    rec['key'] = key; rec['seconds'] = _t.perf_counter() - t; return rec
def main(plan_path, out_path, workers=1):
    plan = json.load(open(plan_path)); done = set()
    if os.path.exists(out_path):
        for line in open(out_path):
            try: done.add(json.loads(line)['key'])
            except Exception: pass
    todo = [(k, x, plan.get('N', 4), plan.get('grid', 24)) for k, x in states(plan) if k not in done]
    print(f"plan {plan_path}: {len(done)} done, {len(todo)} to run, {workers} worker(s)"); sys.stdout.flush()
    t0 = time.perf_counter(); f = open(out_path, 'a')
    if workers > 1:
        import multiprocessing as mp
        with mp.Pool(workers, initializer=_limit) as pool:
            for rec in pool.imap_unordered(work, todo, chunksize=1): _write(f, rec)
    else:
        _limit()
        for item in todo: _write(f, work(item))
    f.close(); dt = time.perf_counter() - t0
    print(f"ran {len(todo)} states in {dt:.1f} s ({dt/max(1,len(todo)):.2f} s/state, {len(todo)/max(dt,1e-9)*3600:.0f} states/hour at {workers} worker(s))")
def _limit():
    try:
        import threadpoolctl; threadpoolctl.threadpool_limits(1)
    except Exception: pass
def _write(f, rec):
    f.write(json.dumps(rec) + "\n"); f.flush(); os.fsync(f.fileno())
def seeds(out_path, seed_path, max_offset=0.05):
    """candidates for the tracer: states with an adjacent node inside the segment and |offset| below max_offset"""
    cands = []
    for line in open(out_path):
        r = json.loads(line)
        if r.get('status') != 'ok' or len(r.get('flat', [])) != 2: continue
        for g in ('upper', 'lower'):
            for (t, o), q in zip(r.get(g + '_geo', []), r.get(g, [])):
                if 0 < t < 1 and abs(o) <= max_offset:
                    cands.append(dict(x=r['x'], N=r['N'], gap=g, t=t, offset=o, seeds=dict(flat=r['flat'], node=q, gap=g)))
    cands.sort(key=lambda c: abs(c['offset'])); json.dump(cands, open(seed_path, 'w'), indent=1)
    print(f"{len(cands)} tracer seeds -> {seed_path}" + (f" (closest |offset| {abs(cands[0]['offset']):.4f})" if cands else ""))
if __name__ == '__main__':
    if sys.argv[1] == 'seeds': seeds(sys.argv[2], sys.argv[3], float(sys.argv[4]) if len(sys.argv) > 4 else 0.05)
    else: main(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 1)
