"""trace.py — predictor/corrector continuation of an event surface. The event condition is the signed offset of a
tracked adjacent-gap node from the tracked flat pair's segment; zero = the node sits on the segment (a crossing).
Walks one free knob, solving for the event knob at each step by secant, carrying node identities throughout.
Usage: python trace.py seeds.json out.json free=phi step=2 count=8 solve=D"""
import json, sys, numpy as np, time
import atlas
def bracket(x0, seeds, solve, center, span, N=4, steps=8):
    """walk outward from `center` in small steps, CARRYING node identities, until two consecutive offsets differ in
    sign; returns (a, b, seeds_at_a) or None. Jumping straight to center +/- span loses narrow-cone nodes."""
    h = max(span, 1e-9) / 4.0
    for direction in (+1, -1):
        s_ = dict(seeds); prev = None
        for i in range(steps + 1):
            v = center + direction * i * h; xx = dict(x0); xx[solve] = v
            r = atlas.measure(xx, s_, N)
            if r is None: break
            s_ = r['seeds']
            if prev is not None and prev[1] * r['offset'] < 0: return prev[0], v, prev[2]
            prev = (v, r['offset'], dict(s_))
    return None
def solve_event(x0, seeds, solve, lo_hi, N=4, tol=1e-7, maxit=14):
    """secant on offset(solve-knob)=0; returns (value, record, seeds) or None"""
    a, b = lo_hi; xa = dict(x0); xa[solve] = a; xb = dict(x0); xb[solve] = b
    ra = atlas.measure(xa, seeds, N); 
    if ra is None: return None
    rb = atlas.measure(xb, ra['seeds'], N)
    if rb is None: return None
    fa, fb = ra['offset'], rb['offset']; sd = rb['seeds']
    for _ in range(maxit):
        if abs(fb) < tol: return b, rb, sd
        if fb == fa: return None
        c = b - fb * (b - a) / (fb - fa); xc = dict(x0); xc[solve] = c
        rc = atlas.measure(xc, sd, N)
        if rc is None: return None
        a, fa, b, fb, sd = b, fb, c, rc['offset'], rc['seeds']; rb = rc
    return (b, rb, sd) if abs(fb) < 1e-5 else None
def main(seed_path, out_path, free, step, count, solve, N=4, pick=0, gap=None):
    S = json.load(open(seed_path))
    if gap: S = [c for c in S if c['gap'] == gap]
    c0 = S[pick]; x = dict(c0['x']); seeds = c0['seeds']
    span = abs(x[solve]) * 0.05 + (2.0 if solve == 'D' else 0.001)
    br = bracket(x, seeds, solve, x[solve], span, N)
    if br is None: print('no sign change of the tracked offset within 16x the initial bracket at the seed state'); return
    first = solve_event(x, br[2], solve, br[:2], N)
    if first is None: print('no event at the seed state'); return
    v, rec, seeds = first; pts = [dict(x=dict(x, **{solve: v}), t=rec['t'], sep=rec['sep'], flat=rec['flat'], node=rec['node'], solves=rec['solves'])]
    print(f"seed point: {free}={x[free]:g} -> {solve}*={v:.6f}  (t={rec['t']:.3f}, pair sep {rec['sep']:.4f})"); sys.stdout.flush()
    prev = None; t0 = time.perf_counter()
    for i in range(count):
        xn = dict(pts[-1]['x']); xn[free] = xn[free] + step
        guess = pts[-1]['x'][solve] + (pts[-1]['x'][solve] - prev if prev is not None else 0.0)   # linear predictor
        prev = pts[-1]['x'][solve]
        br = bracket(xn, seeds, solve, guess, max(span / 2, 0.5), N)
        r = solve_event(xn, br[2], solve, br[:2], N) if br else None
        if r is None:
            print(f"  {free}={xn[free]:g}: event lost (tracked root gone or no sign change in the bracket)"); break
        v, rec, seeds = r; xn[solve] = v
        pts.append(dict(x=xn, t=rec['t'], sep=rec['sep'], flat=rec['flat'], node=rec['node'], solves=rec['solves']))
        print(f"  {free}={xn[free]:g} -> {solve}*={v:.6f}  t={rec['t']:.3f}  pair sep {rec['sep']:.4f}  ({rec['solves']} solves)"); sys.stdout.flush()
    dt = time.perf_counter() - t0
    json.dump(dict(free=free, solve=solve, N=N, model=dict(kinetic='lab_nn_full', geometry='exact', tunnelling='constant'), points=pts), open(out_path, 'w'), indent=1)
    print(f"{len(pts)} curve points in {dt:.1f} s -> {out_path}")
if __name__ == '__main__':
    kw = dict(p.split('=') for p in sys.argv[3:])
    main(sys.argv[1], sys.argv[2], kw.get('free', 'phi'), float(kw.get('step', 2)), int(kw.get('count', 8)), kw.get('solve', 'D'), int(kw.get('N', 4)), int(kw.get('pick', 0)), kw.get('gap'))
