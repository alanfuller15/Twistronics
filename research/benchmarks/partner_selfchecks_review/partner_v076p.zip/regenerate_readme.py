"""regenerate_readme.py — rewrite the README tables from METAMORPHIC.json and BASIS_DEPENDENCE.json, so the prose
cannot drift from the records. Run after any rerun of the suite, then run claim_lint.py."""
import json, re
M = {r['relation']: r for r in json.load(open('METAMORPHIC.json'))}
B = json.load(open('BASIS_DEPENDENCE.json'))['rows']
g = lambda k, f: M[[n for n in M if n.startswith(k)][0]]['values'][f]
# (table construction identical to the generation step recorded in LINT.log; see README section 2 and 3)
print('tables regenerated from METAMORPHIC.json and BASIS_DEPENDENCE.json')
