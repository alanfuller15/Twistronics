"""topo.py — topology measurements with the guards the v073p review required (partner v074p).

V03: the Wilson diagnostic formerly called `min_det` is the minimum determinant of the polar factor of a whole
     k2 loop product; it is renamed `min_polar_det` and reported alongside the quantities it was mistaken for:
     the minimum overlap singular value along the loop, the sewing norm loss, and the reality residual.
V04: every frame is built through a reality-enforcing path; a non-real model (e.g. a C2zT-breaking mass) is refused
     rather than silently projected, and band degeneracy along a sign-holonomy path is rejected.
V05: `lo` selects the band pair; it is no longer ignored.
Valley-aware periodic sewing (v073p) is retained."""
import numpy as np
from scipy.linalg import eigh
from gate import real_basis, classify
from euler import shift_matrix
from braid import node_winding, transport
REAL_TOL = 1e-9
class RealityError(RuntimeError): pass
class DegeneracyError(RuntimeError): pass
class IsolationError(RuntimeError): pass
def frame_at(m, U, k, lo, n=2):
    """real-basis frame of ABSOLUTE bands lo..lo+n-1, with the reality precondition enforced (V04, V05)"""
    HR = U.conj().T @ m.H(k) @ U; res = float(np.abs(HR.imag).max())
    if not res < REAL_TOL: raise RealityError(f'model is not real in the C2zT basis: max|Im| = {res:.2e} meV')
    w, v = eigh(HR.real, subset_by_index=(lo, lo + n - 1)); return w, v
def euler_wilson(m, U, lo=None, nf1=24, nf2=40, gap_tol=1e-6, min_overlap=1e-6):
    """Wilson-loop Euler estimate for the pair (lo, lo+1). Returns a dict of diagnostics, each named for what it is."""
    D = m.dim
    if lo is not None and float(lo) != int(lo): raise ValueError(f'band index {lo!r} is not an integer')
    lo = D // 2 - 1 if lo is None else int(lo); v = int(getattr(m, 'valley', 1))
    if lo < 0 or lo + 1 >= D: raise ValueError(f'band pair (lo, lo+1) = ({lo}, {lo+1}) outside 0..{D-1}')
    S2 = shift_matrix(m, (0, -v)); S1 = shift_matrix(m, (-v, 0))
    bp = b0 = None; ph = []; polar = []; svmin = 1.0; sew = 0.0; realres = 0.0; extmin = np.inf; neighbours_missing = []
    for f1 in np.linspace(0, 1, nf1, endpoint=False):
        fr = []
        for f2 in np.linspace(0, 1, nf2, endpoint=False):
            k = m.frac_to_k(np.array([f1, f2])); HR = U.conj().T @ m.H(k) @ U
            realres = max(realres, float(np.abs(HR.imag).max()))
            if not realres < REAL_TOL: raise RealityError(f'model is not real in the C2zT basis: max|Im| = {realres:.2e} meV')
            w4, vv = eigh(HR.real, subset_by_index=(max(lo - 1, 0), min(lo + 2, D - 1)))
            j = lo - max(lo - 1, 0)
            below = float(w4[j] - w4[j - 1]) if j > 0 else None                      # both neighbours, independently
            above = float(w4[j + 2] - w4[j + 1]) if len(w4) >= j + 3 else None
            for g in (below, above):
                if g is not None:
                    extmin = min(extmin, g)
                    if g < gap_tol: raise IsolationError(f'external gap {g:.3e} meV below gap_tol {gap_tol:.1e} at f=({f1:.3f},{f2:.3f})')
            if below is None or above is None: neighbours_missing.append([float(f1), float(f2)])
            fr.append(vv[:, j:j + 2])
        b = fr[0]
        if bp is not None and np.linalg.det(bp.T @ b) < 0: b = b @ np.diag([1, -1]); fr[0] = b
        if b0 is None: b0 = b
        bp = b; W = np.eye(2)
        for j in range(nf2 - 1):
            M = fr[j].T @ fr[j + 1]; sv = float(np.linalg.svd(M, compute_uv=False).min()); svmin = min(svmin, sv)
            if not (sv > min_overlap): raise IsolationError(f'frame link singular value {sv:.3e} at or below {min_overlap:.1e}')
            W = W @ M
        Msew = fr[-1].T @ (S2 @ fr[0]); ssv = float(np.linalg.svd(Msew, compute_uv=False).min())
        Mrev = fr[0].T @ (S2.T @ fr[-1]); rsv = float(np.linalg.svd(Mrev, compute_uv=False).min())   # both sewing directions
        for sv in (ssv, rsv):
            if not (sv > min_overlap): raise IsolationError(f'sewing singular value {sv:.3e} at or below {min_overlap:.1e}')
        sew = max(sew, float(abs(1.0 - ssv))); svmin = min(svmin, ssv, rsv); W = W @ Msew
        u, s, vt = np.linalg.svd(W); O = u @ vt
        polar.append(float(np.linalg.det(O))); ph.append(float(np.arctan2(O[1, 0], O[0, 0])))
    ext = np.unwrap(np.append(np.unwrap(ph), ph[0]))
    return dict(e2=float((ext[-1] - ext[0]) / (2 * np.pi)), orientation_closure=float(np.linalg.det(bp.T @ (S1 @ b0))),
                min_polar_det=float(min(polar)), min_overlap_singular_value=float(svmin), max_sewing_loss=float(sew),
                max_reality_residual=float(realres), min_external_gap_meV=(None if not np.isfinite(extmin) else float(extmin)),
                mesh=[nf1, nf2], lo=lo, valley=v)
def _ortho(M):
    q, r = np.linalg.qr(M); return q * np.sign(np.diag(r))
def winding_at(m, U, center, r, npts, base, phi0, lo, min_overlap=0.1):
    """Winding of the lower band of the pair (lo, lo+1) around `center`, starting at angle `phi0` so the first loop
    point coincides with the frame's base point (v074p review item 1). Returns (winding, loop coordinates, min link
    singular value); links below `min_overlap` are refused."""
    ts = phi0 + np.linspace(0, 2 * np.pi, npts + 1)
    pts = [center + r * np.array([np.cos(t), np.sin(t)]) for t in ts]
    frames = [frame_at(m, U, m.frac_to_k(p), lo)[1] for p in pts]
    e = frames[0].copy()
    if np.linalg.det(base.T @ e) < 0: e = e @ np.diag([1, -1])
    u = frames[0][:, 0]; alpha = np.arctan2(e[:, 1] @ u, e[:, 0] @ u); tot = 0.0; smin = 1.0
    for j in range(1, npts + 1):
        M = frames[j - 1].T @ frames[j]; smin = min(smin, float(np.linalg.svd(M, compute_uv=False).min()))
        if smin < min_overlap: raise DegeneracyError(f'loop link overlap {smin:.3e} below {min_overlap}')
        P = frames[j] @ frames[j].T; e = _ortho(P @ e); v = frames[j][:, 0]
        if v @ u < 0: v = -v
        u = v; a = np.arctan2(e[:, 1] @ u, e[:, 0] @ u); tot += (a - alpha + np.pi) % (2 * np.pi) - np.pi; alpha = a
    return tot / np.pi, [p.tolist() for p in pts], smin
def transport_path(m, U, a, b, lo, nstep=300, min_overlap=0.1):
    """Parallel transport of the frame along the straight path a -> b; returns (frame, coordinates, min link overlap)."""
    pts = [a + s * (b - a) for s in np.linspace(0, 1, nstep)]
    prev = frame_at(m, U, m.frac_to_k(pts[0]), lo)[1]; smin = 1.0
    for p in pts[1:]:
        fr = frame_at(m, U, m.frac_to_k(p), lo)[1]
        M = prev.T @ fr; smin = min(smin, float(np.linalg.svd(M, compute_uv=False).min()))
        if smin < min_overlap: raise DegeneracyError(f'transport link overlap {smin:.3e} below {min_overlap}')
        if np.linalg.det(M) < 0: fr = fr @ np.diag([1, -1])
        prev = fr
    return prev, [p.tolist() for p in (pts[0], pts[-1])], smin
def pair_charges(m, U, nodes, r=0.012, start_angle=0.0, image=None, lo=None, npts=96, nstep=300, min_overlap=0.1):
    """Relative charge along the straight segment, with the loop start angle, the periodic image and every coordinate
    path explicit and returned (v074p review item 1). The frame base point IS the first loop point."""
    lo = (m.dim // 2 - 1) if lo is None else int(lo)
    d = ((nodes[1] - nodes[0]) + 0.5) % 1 - 0.5 if image is None else np.asarray(image, float)
    off = r * np.array([np.cos(start_angle), np.sin(start_angle)])
    sa = nodes[0] + off; sb = nodes[0] + d + off
    base = frame_at(m, U, m.frac_to_k(sa), lo)[1]
    w1, loop1, s1 = winding_at(m, U, nodes[0], r, npts, base, start_angle, lo, min_overlap)
    moved, tpath, st = transport_path(m, U, sa, sb, lo, nstep, min_overlap)
    w2, loop2, s2 = winding_at(m, U, nodes[0] + d, r, npts, moved, start_angle, lo, min_overlap)
    return float(w1), float(w2), classify(w1, w2), dict(start_angle=float(start_angle), radius=float(r),
        image=list(map(float, d)), base_point=list(map(float, sa)), transport=tpath, loop1_first=loop1[0],
        loop1_last=loop1[-1], loop2_first=loop2[0], loop2_last=loop2[-1], loop_points=npts, transport_points=nstep,
        min_loop1_overlap=s1, min_loop2_overlap=s2, min_transport_overlap=st,
        base_equals_first_loop_point=bool(np.allclose(sa, loop1[0])))
def band_sign_holonomy(m, U, band, axis, c, n=100, min_gap=1e-6, min_overlap=1e-6):
    """Sign holonomy of one real band around a cycle, with reality enforced and degeneracy along the path refused (V04)."""
    v = int(getattr(m, 'valley', 1)); S = shift_matrix(m, (-v, 0)) if axis == 0 else shift_matrix(m, (0, -v))
    prev = first = None; gmin = np.inf
    for t in np.linspace(0, 1, n + 1):
        q = np.array([t, c]) if axis == 0 else np.array([c, t])
        w3, v3 = frame_at(m, U, m.frac_to_k(q), max(band - 1, 0), 3)
        j = band - max(band - 1, 0); gmin = min(gmin, float(min(w3[j] - w3[j - 1] if j > 0 else np.inf, w3[j + 1] - w3[j])))
        if gmin < min_gap: raise DegeneracyError(f'band {band} is degenerate along the cycle (gap {gmin:.2e} meV)')
        vv = v3[:, j:j + 1]
        if prev is not None:
            ov = abs(float(prev[:, 0] @ vv[:, 0]))
            if not (ov > min_overlap): raise DegeneracyError(f'adjacent single-band overlap {ov:.3e} at or below {min_overlap:.1e}')
            if prev[:, 0] @ vv[:, 0] < 0: vv = -vv
        if first is None: first = vv
        prev = vv
    return float(prev[:, 0] @ (S @ first)[:, 0]), float(gmin)
