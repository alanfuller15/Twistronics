"""basis_dependence_check.py — the diagnostic that resolved the MR2 failure, retained as evidence.
Question: is the phi -> phi+60 discrepancy a broken symmetry in the code or a difference of finite models?
Answer (recorded below): index-set membership. It shrinks by two orders of magnitude on a common basis and to
1e-13 meV by N=8 on the native rule."""
import numpy as np, json
from bm_strain import BM
KW = dict(eps=0.004, theta_deg=1.05, kinetic='lab_nn_full', geometry='exact')
rows = []
for N in (4, 6, 8):
    a, b = BM(N=N, phi_deg=17.0, **KW), BM(N=N, phi_deg=77.0, **KW)
    sa, sb = set(a.idx), set(b.idx)
    r = dict(N=N, basis_a=len(sa), basis_b=len(sb), symmetric_difference=len(sa ^ sb),
             d_bandwidth_meV=float(abs(a.flat_bandwidth(8) - b.flat_bandwidth(8))),
             d_remote_gap_meV=float(abs(a.min_remote(ngrid=10, nkeep=3)[0] - b.min_remote(ngrid=10, nkeep=3)[0])), basis='native per angle')
    rows.append(r); print(f"  N={N} native: |basis| {r['basis_a']} vs {r['basis_b']}, sym.diff {r['symmetric_difference']}, "
                          f"d bandwidth {r['d_bandwidth_meV']:.2e} meV, d remote gap {r['d_remote_gap_meV']:.2e} meV")
    if N <= 6:
        c = sorted(sa | sb); a2, b2 = BM(N=N, phi_deg=17.0, index_set=c, **KW), BM(N=N, phi_deg=77.0, index_set=c, **KW)
        r2 = dict(N=N, basis_vectors=len(c), d_bandwidth_meV=float(abs(a2.flat_bandwidth(8) - b2.flat_bandwidth(8))),
                  d_remote_gap_meV=float(abs(a2.min_remote(ngrid=10, nkeep=3)[0] - b2.min_remote(ngrid=10, nkeep=3)[0])), basis='common union')
        rows.append(r2); print(f"  N={N} common ({len(c)} vectors): d bandwidth {r2['d_bandwidth_meV']:.2e} meV, d remote gap {r2['d_remote_gap_meV']:.2e} meV")
json.dump(dict(question='is the phi -> phi+60 discrepancy a code asymmetry or a finite-model difference?',
               answer='finite-model difference: index-set membership differs per angle', rows=rows,
               correction='v024 section 1 attributed a 0.04 meV phi=0 vs 60 remote-gap difference to "N=4 cutoff asymmetry" without testing; the cause is measured here'),
          open('BASIS_DEPENDENCE.json', 'w'), indent=1)
